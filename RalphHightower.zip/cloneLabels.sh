!#/bin/sh

gh label clone RalphHightower/minimaUSCGamecockSandstorm --repo RalphHightower/RH
