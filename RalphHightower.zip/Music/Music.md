---
layout: page
title: Music/Music
#permalink: /Music/
---

## Tenor Saxophone 

| Tenor Saxophones | Date |
|---|---|
| [Best Tenor Saxophone For Beginners (2023) / Ted's List](https://teds-list.com/review/best-tenor-saxophone-for-beginners/ ) |

## Electronic Instruments / Synthesizers

| Electronic Instruments/Synthesizers | Date |
|----|---|
| [Haxophone - A Raspberry Pi-based electronic saxophone with mechanical keys (Crowdfunding) - CNX Software](https://www.cnx-software.com/2023/09/07/haxophone-raspberry-pi-saxophone-mechanical-keys/ ) |
