To create _posts directory 
