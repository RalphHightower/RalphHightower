---
layout: page
title: Opinions/Donald Trump Is a Fucking Idiot
#permalink: /Opinions/
---

## 1. My Personal Opinion

Both political parties fucked up in 2016.

- The Democrats chose Hillary because it was *"her turn"*.
- Whereas the Republicans chose the worst of the worst. The Republican Party died in 2016. It is now the Trump Party, and also his legal defense fund for business, personal, and also government legal problems.

Characteristics of Trump:

- Boastful
- Bully
- Charlatan
- Cheater
- Conceited
- Criminal 
- Crybaby[^112]
- Deceitful
- Dictator
- Draft Dodger 
- Egotistical
- Felon
- Fraud
- Gaslighter
- Grifter
- Huckster
- Mean
- Megalomaniac
- Pathological Liar
- Philanderer
- Sore Loser
- Spoiled Brat
- Sore Winner[^113]
- Tax Cheat
- Zipper Problems[^114]

[^111]: **The Victim Card.** Trump plays the victim card when things don't go his way, or fail. *"It's not my fault. It's the Democrats fault."* Or someone else's fault.
[^112]: Trump whining ***"It’s not fair!"***
[^113]: The *"I got bigger crowds!"* falsehood comparing his inaugural crowd to Obama's.
[^114]: Bill Clinton has the same problem. He can't keep his pants fly closed around women.

### Unfit and Unqualified

Besides the title of this page, Donald Trump is a temperamental, belligerent, mercurial, egotistical, childish, unintelligent ass; he is unfit, and unqualified to be president of the United States of America.

Trump cannot handle the abuse and criticism that he dishes out to others. Presidents live under a microscope where every action, or inaction is scrutinized and either praised or condemned. It's *"damn if you do, damn if you don't"*. For the life of me, I cannot fathom why Trump chose to run.

In the Trump penthouse, here's how I think he made his decision.

Child: "Father, when I grow up, I want to be president."<br />Trump: "Barron, here. Hold my beer. Watch this."[^115]

[^115]: A common phrase that often said before something stupid and more than probably disastrous.

### The Only Person That Can Change My Assessment of Trump

**The only person that can convince me that Donald Trump is not a fucking idiot is Donald Trump himself.**

*How?*

- Tame your temper! Quit throwing **Trumper Tantrums!**
- Quit your pathological lying and tell the God-damned truth!
- Grow up and start treating people with respect. I.e., quit that childish behavior of calling people names.
- Be a true leader! A true leader recognizes team members, and subordinates for their accomplishment, and accepts the blame when things fail. A true leader does not use intimidation and fear.
- Accept the fact that the president lives under a microscope. You will be praised by some and condemned others.

Trump may act *"presidential"* for five minutes, but it is impossible for him to be an adult.

### The Apprentice: White House

As can be seen in the [Presidential Rankings Survey - Historians Rank the Top 10 Presidents / C-SPAN Survey on Presidents 2021](https://www.c-span.org/presidentsurvey2021/?page=overall), section 17 of this page, Trump places dead last among modern day president's.

Trump may have been a breath of fresh air, but nothing has changed about Trump. He's still a *bull in a china shop.* After four years, Trump still thinks that he can run America like a dictatorship.

### Government Ain't Business

Government is not a business and should not be run as a business. Government provides services and has laws to manage the smooth functioning of society. Trump has no business experience running a large corporation having executive officers with a board of directors as independent advisors. The Trump Organization is *simply* a large family-run business, which he runs like a dictatorship.

### Leadership

Leadership is not intimidation and fear. Trump has absolutely, no fucking clue as to how government works. He thinks that he can run government like his family owned business. Trump thinks that he can just bark orders and people will jump through hoops like a circus poodle and that he can fire and hire federal employees at will.

A true leader recognizes and praises their team for their successes and accepts blame and responsibility when things fail. Trump claims credit for others' accomplishment, the *"I did that all by myself!"*, and blames others for his failures, the *"It's not my fault."*[^111]

### Nepotism and Cronyism

Trump's executive office and cabinet was rife with [nepotism](http://www.merriam-webster.com/dictionary/nepotism) and [cronyism](http://www.merriam-webster.com/word-of-the-day/2024/09/03/).

Trump's daughter, Ivanka Kushner and son-in-law, Jared Kushner, were unqualified to be part of his executive office.

### Cult Worship and Idolatry

#### Acolytes and Sycophants

Senator Lindsey Graham (T-SC) has the attention span of a squirrel. After the attempted insurrection on January 6, 2021, Graham said *"That's it! I'm done with Trump."* He was on NBC's Meet The Press after the failed assassination of Trump in 2024. He said that he was supposed to play golf with Trump that weekend. Graham is one of Trump's [sycophants](http://www.merriam-webster.com/dictionary/sycophant). He has he head so far up  Trump's ass that he doesn't know if it's night or day.

[Senator Tim Scott (T-SC) – Meet the Press. May 5, 2024](https://www.nbcnews.com/meet-the-press/video/federal-funding-is-a-privilege-not-a-right-tim-scott-tells-college-presidents-full-interview-210290757680) refused to answer a simple 'yes/no' answer to the question "Will you accept the election results if Trump loses?". As one of Trump's [acolytes](http://www.merriam-webster.com/dictionary/acolyte), Scott is Trump's "lawn jockey". He does not have the courage to stand for what's right.

#### [Opinion / The Messianic Trump Cult - POLITICO](https://www.politico.com/news/magazine/2022/08/31/the-messianic-trump-cult-00054382).  08/31/2022 01:46 PM EDT
Opinion by Jack Shafer

Donald Trump, who regards himself as a divine king unjustly dethroned, called for his royal restoration in a Truth Social posting this week. Complaining that an FBI briefing at Facebook caused the social media site to spike mention of the Hunter Biden laptop, Trump cried foul. Insisting that he would have won the 2020 presidential election “easily” if not for the FBI’s treachery, wrote Trump, “REMEDY: Declare the rightful winner or, and this would be the minimal solution, declare the 2020 Election irreparably compromised and have a new Election, immediately!”

Trump’s delusion that he is the forever president emerged about midway through his term and has gelled into the stuff cults are made from. Abandoning all rationality, he continues wearing his red baseball cap like a crown and expounds on issues like a monarch. His most ardent followers’ minds have become pudding as they predict and repredict his restoration like a messianic cult or a doomsday sect. Like a perpetual going-out-of-business sale run by a shady merchant, Trump’s second-coming is never-ending.

Trump’s loyal subjects have never doubted his perma-president status, no matter how many deadlines he’s missed in taking back power. First, he and his supporters believed that the Jan. 6 riots and the blocking of congressional certification would extend his presidency. When the Capitol siege turned out to be a bloody, tear-gas-stained dud, QAnon theorists asserted that Jan. 20, 2021, — Inauguration Day — would be the day of the Great Awakening following Trump’s signing of the Insurrection Act to declare martial law and conduct mass arrests of his enemies. Michael Flynn, who served as Trump’s national security adviser for about 15 minutes in 2017, had claimed in December that Trump could “basically rerun an election” in several states. Then Trump’s reinstatement was pegged for the “real” inauguration day, March 4, 2021. Do you notice a pattern? Following the cult dictum to predict often and grandly as nobody will remember long enough to hold you accountable, that day came and went. Then the Trump cult set a new date of March 20 for his return because he would somehow have legal control of the military until then.

You might take pity on the citizen who fell for the cult’s mumbo-jumbo, but they number in the tens of millions, and they gladly donate to his political fronts to help him unsteal the 2020 election he clearly lost. A June 2021 poll found that 29 percent of Republicans believed Trump had a chance of being reinstated by the end of the year. Even though there is no constitutional mechanism for a rejection of the 2020 results or a do-over election, Trump was telling people he expected his reinstatement by August. He’s coming! He’s coming! My Pillow magnate Mike Lindell fired up the cult that summer by pegging the second coming as Aug. 13, 2021. That proved to be a wash, too, as was the revised date of Thanksgiving. Like any true believer, Lindell is still at it, recently staging a flop of a stolen-election conference in Springfield, Mo. Lindell — along with Flynn, John Eastman and Steve Bannon — has also trumpeted the cockamamie idea that Biden’s 2020 win could still be “decertified” in key states. By touting Trump’s second coming no matter how many times he fails to return, Trump’s followers have branded themselves a cult.

How did Trump and his believers come by these preposterous notions? As a serial bilker of creditors, investors, donors to his philanthropy and his fund-raising organization, students at his “university,” workers, and contractors, Trump was already well positioned for such a role. And then he learned during the 2016 campaign what an easy touch the religious community could be. Preachers as varied as Jeremiah Johnson and, later, Franklin Graham vowed that God was moving the scenery in support of his 2016 victory. By 2020, a poll by Pew Research of U.S. adults found that 27 percent believed God had chosen Trump for the office. Small wonder Trump rallies resemble religious assembles in which the faithful worship their god.

It’s one thing for the religious rank and file to believe in Trump’s status as God’s right-hand man, but how do we account for the prominent Republicans who endorsed the idea? Brad Parscale, his campaign manager, called him a “savior” called into service by God. White House press secretary Sarah Huckabee Sanders told Christian Broadcasting Network viewers in 2019 that God “wanted Donald Trump to become president.” Secretary of State Mike Pompeo, not normally a supernatural theorist, speculated that Trump had been sent to save Israel from Iran. Trump took to the testimonials with the enthusiasm of a convert. During a 2019 scrum with reporters, he looked to the skies and stated, “I am the chosen one.” He later claimed he was being sarcastic, but not everybody believed that excuse. Two months later, Secretary of Energy Rick Perry confided that he had informed Trump he was the “chosen one” designated to lead the country. In 2020, Sen. David Perdue of Georgia fluffed Trump’s ego by calling him “providential.”

As Trumped settled into his presidency, he began to regard it as a potentially permanent position. If God has chosen you to lead, who are you to surrender the position? In 2018, he “joked” that Chinese President Xi Jinping’s status as “president for life” was “great,” continuing, “Maybe we’ll give that a shot someday.” In 2019, he “joked” again saying he might remain in the White House “at least for 10 or 14 years.” These forever president sentiments blossomed again two months later in his retweet of Jerry Falwell Jr.’s view that a two-year extension on his first term was warranted for the time the Mueller probe had stolen from his presidency.

Although evicted from the White House 19 months ago, Trump still postures as if he were president. In addition to calling for reinstatement and a do-over election, Trump ensures that his office calls him the “45th president,” not the former president. He continues to unlawfully use the presidential seal for commercial purposes. And his capricious handling of sensitive and secret documents at Mar-a-Lago — his idea that the papers belong to him and that he’s above the law — make the case that he’s come to believe in his own, permanent divinity. Trump said in 2019 that being president gave him “the right to do whatever I want,” which is consistent with thinking you’re God’s co-pilot.

The great obstacle in accepting Trump’s divine status is that he has never convincingly presented himself as a man of God. Remember the “Two Corinthians” incident or that time in 2015 when he said the Bible was his favorite book, but he couldn’t name a favorite verse? Perhaps Trump was sent to earth to work wonders. But what if he’s not a messenger from heaven but from the other place?

####  [The One Way History Shows Trump’s Personality Cult Will End - POLITICO](https://www.politico.com/news/magazine/2022/04/16/history-shows-trump-personality-cult-end-00024941).  04/16/2022 07:00 AM EDT
By MICHAEL KRUSE

In the summer of 2020, Ruth Ben-Ghiat was putting the final touches on her history of modern autocracy. She had to do it, though, without the benefit of knowing whether one of her most important subjects would remain in power come November.

But she wasn’t exactly in the dark either.

She had seen enough of Donald Trump’s behavior over the preceding five years to know how neatly he lined up with other strongmen she had studied and how his autocratic tendencies would influence his behavior whether he won or lost.

“I just predicted that he wouldn’t leave in a quiet manner,” Ben-Ghiat, a professor of history and Italian studies at New York University told me recently. “He’s an authoritarian, and they can’t leave office. They don’t have good endings and they don’t leave properly.”

Nearly two years later — after a riot, an impeachment, and a monomaniacal campaign to punish the Republicans who tried to hold him accountable — Ben-Ghiat has ample proof of her thesis. And she professes even more concern that Trump’s sway over the GOP has permanently transformed the party’s political culture. “He’s changed the party to an authoritarian party culture,” she told me. “So not only do you go after external enemies, but you go after internal enemies. You’re not allowed to have any dissent.”

With the midterms and some key governors races approaching, Ben-Ghiat is looking around the corner again. She sees dangerous signs of autocracy seeping into state houses and governors’ mansions where leaders such as Florida Gov. Ron DeSantis are executing policies and enacting laws that mimic Trump but with a smoother, less bombastic style.

She insists her urgent warnings should not be construed as fatalism. Throughout our interview she leavened her direst predictions with a pragmatic if not sunny optimism. Political violence is more likely than an actual civil war; a Republican takeover in November would be catastrophic but she remains heartened by the ability of American voters to “interrupt an autocratic personality who’s in the middle of his project;” and ballot box victories alone don’t stop autocrats but the law can. “It takes prosecution and conviction to deflate their personality cults,” Ben-Ghiat said. “That’s what it takes.”

This interview has been edited for length and clarity.

**Michael Kruse:** We’re coming up on seven years since Donald Trump came down the escalator at Trump Tower and announced he was running for president. I’m wondering where in your estimation we are in this country in the timeline of increasing authoritarianism.

**Ruth Ben-Ghiat:** When somebody like Trump comes on the scene and holds office, it’s really like an earthquake or a volcano, and it shakes up the whole system by gathering in this big tent all the extremists, all the far-right people, and giving them legitimation. The GOP was already going away from a democratic political culture, but he accelerated it and normalized extremism and normalized lawlessness. And so the GOP over these years has truly, in my estimation, become an authoritarian far-right party. And the other big story is that his agenda and his methods are being continued at the state level. Some of these things were on the agenda way before he came in, like getting rid of abortion rights and stuff like that. But these states are really laboratories of autocracy now, like Florida, Texas.

The final thing I’d say is machismo [is] up there as a tool of rule alongside propaganda and corruption. Getting ahead as a man [in this political system] means being more like Trump. And so you saw Mike Pompeo, who started talking about “swagger” and he was a very different kind of State Department head. And now you have people like Ron DeSantis who even absorbed the hand gestures of Trump. And so at the elite level, the political system is shaped by Trump, and every day we see his legacy.

**Kruse:** What would you say to those in this country who say, “No, the Republicans aren’t the autocrats. It’s the Democrats who are the autocrats. It’s Joe Biden. It’s other Democrats with power who are making us wear masks or take vaccines we don’t want to take. They’re the ones who are behaving more in autocratic ways, not the Republicans.”

**Ben-Ghiat:** One of the big talking points and strategy of right-wing authoritarianism, is to label democratic systems as tyrannical. Mussolini was the first to say that democracies are tyrannical, democracies are the problem. And there’s a whole century’s worth of the strategy of calling sitting Democrats, who you want to overthrow, dictators. Biden as a social dictator, [is] a phony talking point. It has so many articulations from “They’re forcing us to wear masks.” And you have people like DeSantis who are doing this very subversive thing of saying, “Florida’s the free state. You can have refuge from the dictatorship of Biden here.” And what this is designed to do is discredit the sitting democratic administration in order to create, a myth of freedom. January 6 was actually marketed as the violence [being] in the service of freedom, and you were overthrowing a dictator.

**Kruse:** Where is Trump in his own timeline? Is he in your estimation getting weaker, getting stronger, in a holding pattern?

**Ben-Ghiat:** The genius of the “big lie” was not only that it sparked a movement that ended up with January 6 to physically allow him to stay in office. But psychologically the “big lie” was very important because it prevented his propagandized followers from having to reckon with the fact that he lost. And it maintains him as their hero, as their winner, as the invincible Trump, but also as the wronged Trump, the victim. Victimhood is extremely important for all autocrats. They always have to be the biggest victim.

So the “big lie” maintained Trump’s personality cult versus seeing him as just another president who was voted out of office. Americans traditionally always accepted that when your time is up, no matter how popular you were, you were gone. Trump disrupted that because he’s different from any other president, Republican or Democrat. He’s an authoritarian, and they can’t leave office. They don’t have good endings and they don’t leave properly. And I predicted — I had to turn in [my] book in the summer of 2020 — and I just predicted that he wouldn’t leave in a quiet manner. The “big lie” allowed him to psychologically never leave. So he’s in this kind of limbo. As an authoritarian, his other job has been to make sure to keep hold of the party so no rivals emerge, so that he could [not] be eclipsed by a younger version of himself. And that would be DeSantis.

**Kruse:** Have you been surprised at how successful he’s been in this regard, especially considering he doesn’t have Twitter? As you referenced, Truth Social has been more or less a failure to this point. He is doing this through emails and [conservative] media hits.

**Ben-Ghiat:** The Twitter was for the masses, to keep the masses indoctrinated, and I see Trump as one of the most successful propagandists of the early 21st century. He tweeted over 120 times a day. But that was for the masses. I wasn’t talking about voters as much as how has he kept the elites tethered to him. And that has nothing to do with Twitter. That has to do with what he’s always done: collecting compromising information, threatening, and he’s changed the party to an authoritarian party culture. So not only do you go after external enemies, but you go after internal enemies. You’re not allowed to have any dissent. And it’s not just when the leader was going to be impeached. In February 2021, during the second impeachment, and Republicans who voted to impeach him had to buy body armor because they were being threatened.

The big question will be what will happen in the coming months so that he can retain that power because he’s very toxic. There’s always this worry that maybe the investigations will bring more things out, so it’s not a done deal that he will get the nomination. But he’s been remarkably successful in ways that don’t surprise me at all. Because that’s how authoritarians are. They’re personality cults, even if they rule in a democracy like [Italy’s former prime minister Silvio] Berlusconi did. Berlusconi’s personality cult did not deflate until he was convicted, which he eventually was. That’s what it takes. It takes prosecution and conviction to deflate their personality cults.

**Kruse:** You recently wrote, “Ron DeSantis is turning Florida into his own mini-autocracy.” Why is he an autocrat?

**Ben-Ghiat:** He has autocratic tendencies. What’s so interesting is he was a Reaganite and then he had clearly some kind of epiphany when Trump came on the scene. He had that campaign video that showed his house being transformed into an altar for Trump. And he got the endorsement. He has absorbed the lessons of what you need to get ahead in the GOP today. And that is to be a forceful bully, even to high school students. The way he carries himself and speaks has gotten much more aggressive. And he’s also very smartly tried to turn Florida into this refuge for all who are oppressed by Biden. He invited New York city cops and people from all over the nation who are oppressed by federal government vaccine [rules], or state mandates, [to] come to Florida and be free. And so that’s one way he’s setting up Florida to be the fiefdom of a certain politics, a certain ideology, that he clearly then wants to take national. And in fact his spokesperson, Christina Pushaw, says, “Make America Florida.”

**Kruse:** Is it fair to see DeSantis as a very capable, committed student, whereas Trump is more of an instinctual autocrat?

**Ben-Ghiat:** It could happen in a quieter way. I think that it’s not out of the realm of possibility, because if the Republicans tried to impeach Biden and impeach Harris, there would be protests. Whether that becomes a civil war is very different because it’s predominantly only one side which is armed, first of all. So Walter is right. She wanted to point out how far our democracy has eroded. And it’s not out of the realm of possibility that we could end up with some kind of form of autocracy because that’s what’s being set up by all of the assaults on our electoral system. And Bannon’s been working very hard at this, too, from his own vantage point. It’s intimidation of voters, removing voters, look at all these threats to election officials — so you get them out of the system — this all corresponds to what we call “autocratic capture.” There’s a movement going on. This is what I mean by more — it’s more legalistic and quieter. And that doesn’t tend to bring out people into the streets. Because it’s an evolution and it’s happening slowly, slowly, slowly, and big protests are occasioned by an event.

**Kruse:** Are there signs in these developments of a particularly American style of autocracy?

**Ben-Ghiat:** The wild card is guns. No other country in peace time has 400 million guns in private hands. And no other country in peacetime has militias allowed to populate, has sovereign sheriffs, has so many extremists in the military, and that matters because of these other things. And in fact, if January 6 didn’t bring out a massive protest, what is going to bring out a massive protest? Because that showed that groups of people who were there were people unaffiliated with any Proud Boys or any radical group. And Robert Pape, who studied them, called them middle-aged, middle class, but they were all armed. Some of them had private arsenals and they showed up at January 6. So that’s the wild card. That’s one thing that’s extremely American, that violence, that the population believes it has the right to rebel against tyrannical government. Like Matt Gaetz says: The Second Amendment is not just about hunting. And here we go back to the idea of Biden as a dictator. And that only works if your citizenry is armed and ours is to a degree that no other country is in the entire world.

**Kruse:** Given the stakes, what are Democrats doing wrong right now?

**Ben-Ghiat:** The reason that Trump was able to shift the political culture, Trump and his allies, is that he imposed an authoritarian party culture [with] unified messaging. Propaganda needs to be repeated with small variations. All the different Fox News hosts, all the GOP politicians, you can tell when the various talking points come up, because they get echoed by all these lawmakers and throughout Fox. Now Democrats by their nature are not going to impose unified messaging. And so Democrats don’t have that force of concentration of message, that repetition, and that’s a failing in this environment.

## 2. Make America Golf Again

### Conversation with Copilot

***"Ralph Hightower"***

***"How many times did each of these presidents, George W. Bush, Bill Clinton, Barak Obama, and Donald Trump, play golf or go on vacation? Group by four year terms."***

**Copilot:**

Here’s a breakdown of the golf and vacation activities for each president during their terms:

- George W. Bush
    - First Term (2001-2005):
        - Golf: Played 24 rounds of golf before stopping in 2003[^211].
        - Vacation: Took 407 vacation days, mostly at his ranch in Crawford, Texas[^212]
    - Second Term (2005-2009):
        - Golf: Did not play golf.
        - Vacation: Took 613 vacation days[^212].
- Bill Clinton
    - First Term (1993-1997):
        - Golf: Played 71 rounds of golf[^213].
        - Vacation: Took 174 vacation days[^214].
    - Second Term (1997-2001):
        - Golf: Played 103 rounds of golf[^213].
        - Vacation: Took 171 vacation days[^214].
- Barack Obam
    - First Term (2009-2013)
        - Golf: Played 113 rounds of golf[^215].
        - Vacation: Took 92 vacation days[^216]
    - Second Term (2013-2017)
        - Golf: Played 220 rounds of golf[^215].
        - Vacation: Took 236 vacation days[^216].
- Donald Trump
    - First Term (2017-2021):
        - Golf: Played 308 rounds of golf[^217].
        - Vacation: Took 381 vacation days[^218].

If you have any more questions or need further details, feel free to ask!

[^211]: [United States presidential vacations - Wikipedia.](https://en.wikipedia.org/wiki/United_States_presidential_vacations)
[^212]: [Presidential Vacations - FactCheck.org.](https://www.factcheck.org/2014/08/presidential-vacations/)
[^213]: [Presidential vacations: Which commander in chief took the most time off?.](https://www.cleveland.com/nation/2017/08/presidential_vacations_who_too.html)
[^214]: [President Obama's Vacation Days - FactCheck.org.](https://www.factcheck.org/2010/01/president-obamas-vacation-days/)
[^215]: [How many times did President Barack Obama play golf while in office?.](https://thegolfnewsnet.com/ryan_ballengee/2024/04/20/how-many-rounds-president-barack-obama-play-golf-office-103838/)
[^216]: [We've crunched the numbers, and it's official: President Obama played A ....](https://www.golfdigest.com/story/weve-crunched-the-numbers-and-its-official-president-obama-played-a-lot-of-golf-while-in-office)
[^217]: [Fact check: Trump has spent far more time at golf clubs than ... - WRAL.](https://www.wral.com/story/fact-check-trump-has-spent-far-more-time-at-golf-clubs-than-obama-did-as-president/19113812/)
[^218]: [Fact check: Did Obama or Bush take more vacation? - Reno Gazette Journal.](https://www.rgj.com/story/news/2014/09/07/fact-check-obama-bush-take-vacation/14948189/)
[^219]: [Fact check: Who took more presidential vacations? - USA TODAY.](https://www.usatoday.com/story/news/politics/2014/08/28/fact-check-presidential-vacations/14730083/)
[^210]: [How many times did President Donald Trump played golf while in office?](https://thegolfnewsnet.com/ryan_ballengee/2024/04/16/how-many-times-president-donald-trump-played-golf-in-office-103836/)
[^211]: [How Many Times Has President Trump Played Golf? - Statista.](https://www.statista.com/chart/23464/estimated-number-of-times-president-trump-played-golf/)
[^212]: [Tracking President Trump's visits to Trump properties - NBC News.](https://www.nbcnews.com/politics/donald-trump/how-much-time-trump-spending-trump-properties-n753366)
[^213]: [How do Trump's days away from the White House compare to his ... - CBS News.](https://www.cbsnews.com/news/how-do-trumps-days-away-from-the-white-house-compare-to-his-predecessors/)
[^214]: https://twitter.com/ryanballengee.
[^215]: https://facebook.com/ryanballengeegolf.
[^216]: https://instagram.com/ryanballengee
[^217]: https://youtube.com/@ryanballengeegolf

## 3. Personal Life

### Trump's Wives

| Wife | Married | Divorced | Nationality | Settlement | Alimony | Fringe Benefits |
|---|---|---|---|---|---|---|
| Ivana Marie Zelníčková[^301] | 1977 | 1990[^313] | Czechoslovakia (until 1993)<br />Czech Republic (from 1993)<br />Austria (from 1973)<br />United States (from 1988) | \$14 million9[^302]<br />a 45-room mansion, Greenwich, Conn.<br />Trump Plaza apartment | \$650,000 annually | use of the 118-room Mar-a-Lago mansion in Florida for one month a year |
| Marla Maples[^311] | 1993 | 1999[^312]<sup>,</sup>[^322] | American | between 1 – 5 million | | Apartment in one of Trump's buildings |
| Melania (Melanija) Knavs[^321] | 2005 | *not yet* | Yugoslavia. 1970-1991<br />Slovenia. 1991–present<br />United States. 2006–present.

In 2018, Knavs and her husband, Viktor, obtained green cards and then became naturalized U.S. citizens using the U.S.'s family-based immigration program, which Trump had denounced as "chain migration".[^323]<br />Correal, Annie; Cochrane, Emily (August 9, 2018). "Melania Trump's Parents Become U.S. Citizens, Using 'Chain Migration' Trump Hates". The New York Times. Archived from the original on April 24, 2022. Retrieved January 10, 2024.<br />[4] Cochrane, Emily (February 21, 2018). "Questions Swirl as Melania Trump's Parents Obtain Green Cards". The New York Times. Washington. Archived from the original on January 10, 2024. Retrieved January 10, 2024.<br />

[Melania Trump’s Parents Become U.S. Citizens, Using ‘Chain Migration’ Trump Hates - The New York Times](https://web.archive.org/web/20220424173843/https://www.nytimes.com/2018/08/09/nyregion/melania-trumps-parents-become-us-citizens.html). Aug. 9, 2018

[Questions Swirl as Melania Trump’s Parents Obtain Green Cards - The New York Times](https://web.archive.org/web/20240110084207/https://www.nytimes.com/2018/02/21/us/politics/melania-trump-parents-immigration.html). Feb. 21, 2018

[^301]: Wikipedia – [Ivana Trump](https://en.wikipedia.org/wiki/Ivana_Trump?wprov=sfla1)
[^302]: Her lawyers said that she was entitled to half his wealth, valued at \$5 billion. Trump was near bankruptcy, and the bank provided Trump \$375,000 monthly living allowance.[^311]
[^303]: Wikipedia – [Ivana Trump](https://en.wikipedia.org/wiki/Ivana_Trump?wprov=sfla1). Footnote 1.
[^311]: Wikipedia – [Marla Maples](https://en.wikipedia.org/wiki/Marla_Maples?wprov=sfla1)
[^312]: Wikipedia – [Marla Maples](https://en.wikipedia.org/wiki/Marla_Maples?wprov=sfla1). 1996, Trump fired his bodyguard Spencer Wagner after a police officer found Maples and the bodyguard together under a lifeguard stand on a deserted beach at 4:00 a.m. Both Maples and Trump denied that she was having an affair, despite reports in the National Enquirer and other tabloids; the bodyguard himself told conflicting stories about the incident. Maples and Trump separated in May 1997 and divorced on June 8, 1999
[^313]: 1989 when—on vacation in Aspen, Colorado—they were observed fighting after Ivana encountered Donald's mistress Marla Maples.
[^321]: Wikipedia – [Melania Trump](https://en.wikipedia.org/wiki/Melania_Trump?wprov=sfla1)
[^322]: Wikipedia – [Melania Trump](https://en.wikipedia.org/wiki/Melania_Trump?wprov=sfla1). Trump met Melanija in 1988, while still married to Maples. Interesting overlap.
[^323]: Wikipedia – [Amalija Knavs](https://en.wikipedia.org/wiki/Amalija_Knavs?wprov=sfla1)

### Trump's Mistresses (Extramarital Affairs, One Night Stands)

It is my opinion that Trump was *"test driving"* Marla Maples while still married to Ivana Trump. Likewise, he was *"test driving"* Melania Trump while still married to Marla Maples. Of course everyone knows about porn star Stormy Daniels and Donald Trump, and to a lesser extent, Playboy Playmate, and Playmate Of The Year, Karen McDougal while married to Melania Trump. Melania's warranty has expired and Donald is going too trade her in for a newer model.

Donald Trump has the same problem that Bill Clinton does.[^351]

[^351]: A problem with their zipper.

#### Wikipedia – [Donald Trump sexual misconduct allegations](https://en.wikipedia.org/wiki/Donald_Trump_sexual_misconduct_allegations?wprov=sfla1)

#### Wikipedia – [Stormy Daniels–Donald Trump scandal](https://en.wikipedia.org/wiki/Stormy_Daniels%E2%80%93Donald_Trump_scandal?wprov=sfla1)

#### Wikipedia – [Karen McDougal](https://en.wikipedia.org/wiki/Karen_McDougal#Alleged_affair_with_Donald_Trump?wprov=sfla1)

## 4. Donald Trump is a Perv and Voyuer

Apparently, since Trump owned the Miss USA, and Miss Teen USA pageants, he thought that it was his right to walk into their dressing rooms. Many women and teenage girls were in various states of undress, ranging from topless to totally nude.

Several former Miss USA and Miss Teen USA contestants accused Trump of entering the dressing rooms of beauty pageant contestants while contestants were in various stages of undress. Trump had already referred to this practice during a 2005 interview on The Howard Stern Show, saying he could "get away with things like that" because he owned the Miss Universe franchise. In October 2019, the book All the President's Women: Donald Trump and the Making of a Predator contained 43 additional allegations of sexual misconduct against Trump[^411]

Trump has denied all the allegations against him, saying he has been the victim of media bias, conspiracies, and a political smear campaign. In October 2016, Trump publicly vowed to sue all the women who have made allegations of sexual misconduct against him, as well as The New York Times for publishing the allegations.[^412]

[^411]: Wikipedia – [Donald Trump sexual misconduct allegations](https://en.wikipedia.org/wiki/Donald_Trump_sexual_misconduct_allegations?wprov=sfla1)
[^412]: [Book review of All the President's Women: Donald Trump and the Making of a Predator by Barry Levine and Monique El-Faizy - The Washington Post](https://www.washingtonpost.com/outlook/a-thorough-revolting-history-of-trumps-behavior-toward-women/2019/10/23/3dea9ac4-d00d-11e9-b29b-a528dc82154a_story.html). October 23, 2019 at 12:02 p.m. EDT

## 5.	Not a Savvy Businessman. Multiple Bankruptcies. Scores of Business Failures.

Trump is not the savvy businessman that he thinks he is and brags to everyone that he is.

1. Six bank​rupt​cies[^511]
    1. 1991: In 1991, Trump Taj Mahal was unable to service its debt and filed Chapter 11 bankruptcy. Forbes indicated that this first bankruptcy was the only one where Trump's personal financial resources were involved. Time, however, maintains that \$72 million of his personal money was also involved in a later 2004 bankruptcy.
    2. 1992: On November 2, 1992, the Trump Plaza Hotel filed Chapter 11 bankruptcy, and Trump lost his 49 percent stake in the luxury hotel to Citibank and five other lenders. In return Trump received more favorable terms on the remaining \$550+ million owed to the lenders, and retain his position as chief executive, though he would not be paid and would not have a role in day-to-day operations.
    3. 2004: Donald Trump's third corporate bankruptcy was on October 21, 2004, involving Trump Hotels & Casino Resorts, the publicly traded holding company for his three Atlantic City casinos and some others. Trump lost over half of his 56% ownership and gave bondholders stock in exchange for surrendering part of the debt. No longer CEO, Trump retained a role as chairman of the board. In May.
    4. 2005: The company emerged from bankruptcy as Trump Entertainment Resorts Holdings. In his 2007 book, Think BIG and Kick Ass in Business and Life, Trump wrote: "I figured it was the bank's problem, not mine. What the hell did I care? I actually told one bank, **'I told you you shouldn't have loaned me that money. I told you the goddamn deal was no good.'**"[^111]
    5. 2009: Trump's fourth corporate bankruptcy occurred in 2009, when Trump and his daughter Ivanka resigned from the board of Trump Entertainment Resorts; four days later the company, which owed investors \$1\.74 billion against its \$2\.06 billion of assets, filed for Chapter 11 bankruptcy. At that time, Trump Entertainment Resorts had three properties in Atlantic City: Trump Taj Mahal, Trump Plaza Hotel and Casino (closed in 2014), and Trump Marina (formerly Trump's Castle, sold in 2011). Trump and some investors bought the company back that same year for \$225 million. As part of the agreement, Trump withdrew a \$100 million lawsuit he had filed against the casino's owners alleging damage to the Trump brand. Trump re-negotiated the debt, reducing by over \}}\$1 billion the repayments required to bondholders.
    6. 2014: Trump sued his former company to remove his name from the buildings since he no longer ran the company, having no more than a 10% stake; he lost the suit. Trump Entertainment Resorts filed again for bankruptcy in 2014 and was purchased by billionaire philanthropist Carl Icahn in 2016, who acquired Trump Taj Mahal in the deal.
2. By mid-2016, it was alleged that the organization, specifically under the leadership of Donald Trump, had a history of not paying for services rendered. Several hundred contractors or workers for the organization have filed lawsuits or liens saying they were not paid for their work, and others say they had to settle for cents on the dollar.[^513]
3. Convicted of tax fraud for inflating property values for better finance terms and rates and deflating property values for property tax. NY. This practice of inflating and deflating property values when convenient is sure to occur in other states where Trump owns property.
4. Convicted on 34 counts of falsifying business records for hush money payments made to former adult film actor Stormy Daniels.
5. Failed businesses[^515]<sup>,</sup>[^516]
    1. Donald J. Trump Foundation – charitable foundation shut down in 2018 due to legal issues
    2. Donald J. Trump Signature Collection, a line of menswear launched at Macy's in 2004, and involved in a lawsuit and subsequent trial. Discontinued in 2015, after comments Trump made about Mexican immigrants.
    3. [Donald J. Trump State Park](https://en.wikipedia.org/wiki/Donald_J._Trump_State_Park?wprov=sfla1) — Wikipedia. Currently closed by New York State Government; will be renamed.
    4. GoTrump.com, a travel booking website
    5. Harrah’s at Trump Plaza in Atlantic City, New Jersey; formerly a 50/50 partnership with Harrah’s, later wholly owned by the company and renamed the Trump Plaza. Closed on September 16, 2014; demolished February 17, 2021.
    6. New Jersey Generals
    7. Select By Trump (line of coffee drinks)
    8. Steel Pier, sold in 2011
    9. The Trump Network, a multi-level marketing company that sold vitamins
    10. Tour de Trump, a bicycle race held in 1989 and 1990.
    11. Trump 29 Casino in Coachella, California; formerly a 50/50 partnership with the Twenty-Nine Palms Band of Mission Indians of California. In 2006 Trump officially exited the partnership
    12. Trump Airlines — Trump borrowed \$245 million to purchase Eastern Air Shuttle. He branded it Trump Airlines. He added gold bathroom fixtures. Two years later Trump could not cover the interest payment on his loan and defaulted.
    13. Trump Beverages — Although Trump touted his water as "one of the purest natural spring waters bottled in the world," it was simply bottled by a third party. Other beverages, including Trump Fire and Trump Power, seem not to have made it to market. And Trump's American Pale Ale died with a trademark withdrawal.
    14. Trump Casino in Indiana.
    15. Trump Castle (renamed Trump Marina in 1997) in Atlantic City, New Jersey; sold to Landry’s, Inc. in 2011 and renamed the Golden Nugget Atlantic City.
    16. Trump Chocolate
    17. Trump Club Privee Casino - Canouan - Saint Vincent<sup>[citation needed]</sup>
    18. Trump Drinks (energy drink for the Israeli and Palestinian markets)
    19. Trump Entertainment Resorts. Atlantic City, New Jersey. 1995 — 2016.
    20. Trump Fragrances — Success by Trump, Empire by Trump, and Donald Trump: The Fragrances all failed due to being discontinued, perhaps as a result of few sales.
    21. Trump Game — Milton Bradley tried to sell it. As did Hasbro. After investment, the game died and went out of circulation.
    22. Trump Home, an upscale furniture line
    23. Trump Institute
    24. Trump Magazine — Trump Style and Trump World were renamed Trump Magazine to reap advertising dollars from his name recognition. However, Trump Magazine also went out of business.
    25. Trump Marina
    26. Trump Mattress — Serta stopped offering a Trump-branded mattress, again likely due to slacking sales.
    27. Trump Model Management
    28. Trump Mortgage — Trump told CNBC in 2006 that "I think it's a great time to start a mortgage company. … The real-estate market is going to be very strong for a long time to come." Then the real estate market collapsed. Trump had hired E.J. Ridings as CEO of Trump Mortgage and boasted that Ridings had been a "top executive of one of Wall Street's most prestigious investment banks." Turned out Ridings had only six months of experience as a stockbroker. Trump Mortgage closed and never paid a \$298,274 judgment it owed a former employee, nor the \$3,555 it owed in unpaid taxes.
    29. Trump Office, a line of executive office chairs launched in 2007 for Staples Inc
    30. Trump Plaza Hotel and Casino. Atlantic City, New Jersey. 1984 — 2014.
    31. Trump Productions (television production company)
    32. Trump Sports & Entertainments
    33. Trump Steakhouse.
    34. Trump Steaks — Trump closed Trump Steaks due to a lack of sales while owing Buckhead Beef \$715,000.
    35. Trump Taj Mahal, a casino resort on the Atlantic City boardwalk; closed on October 10, 2016. Purchased by Hard Rock International and reopened as the Hard Rock Hotel & Casino Atlantic City in June 2018.
    36. Trump Tower Tampa — Trump sold his name to the developers and received \$2 million. Then the project went belly-up with only \$3,500 left in the company. Condo buyers sued Trump for allegedly misleading them. Trump settled and paid as little as \$11,115 to buyers who had lost hundreds of thousands of dollars.
    37. Trump University or the Trump Entrepreneur Initiative — Trump staged wealth-building seminars costing up to \$34,995 for mentorships that would offer students access to Trump's secrets of success. Instructors turned out to be motivational speakers sometimes with criminal records. Lawsuits and criminal investigations abound.
    38. Trump Vodka — Business failed due to a lack of sales.
    39. Trump World’s Fair at Trump Plaza in Atlantic City, New Jersey. Operated as a wing of Trump Plaza, but with its own casino license, it was closed in 1999, and demolished in 2000.
    40. Trump's Travel Site — GoTrump.com was in business for one year. Failed.
    41. Trumpnet — A telephone communication company that abandoned its trademark.
    42. Truth Social — This existing Trump business owes big money, and may well be breathing its last.

[The RNC Has Been Bankrolling Trump's Legal Bills. If He Runs, They're Cutting Him Off. / Vanity Fair](https://www.vanityfair.com/news/2022/07/rnc-trump-running-2024-legal-bills). July 28, 2022

[^511]: Wikipedia – [Personal and business legal affairs of Donald Trump](https://en.wikipedia.org/wiki/Personal_and_business_legal_affairs_of_Donald_Trump#Use_of_bankruptcy_laws?wprov=sfla1)
[^512]: Wikipedia – [Trump Entertainment Resorts](https://en.wikipedia.org/wiki/Trump_Entertainment_Resorts?wprov=sfla1)
[^513]: NBC News – [Hundreds Claim Donald Trump Doesn't Pay His Bills in Full](https://www.nbcnews.com/news/us-news/hundreds-claim-donald-trump-doesn-t-pay-his-bills-n589261). June 9, 2016, 6:07 PM EDT / Updated June 10, 2016, 5:20 AM EDT
[^514]: Wikipedia  – [Personal and business legal affairs of Donald Trump](https://en.wikipedia.org/wiki/Personal_and_business_legal_affairs_of_Donald_Trump?wprov=sfla1)
[^515]: Political Opinion Online – [When it comes to business, former president's track record dismal](https://www.publicopiniononline.com/story/opinion/columnists/2022/09/07/when-it-comes-to-business-former-president-trump-track-record-dismal/65474745007/). September 7, 2022.
[^516]: Wikipedia – [List of things named after Donald Trump](https://en.wikipedia.org/wiki/List_of_things_named_after_Donald_Trump?wprov=sfla1)

## 6. Tax Cheat

Chairman Neal’s request for Trump’s taxes came after the president’s ex-lawyer Michael Cohen testified before Congress on February 27 that as a businessman, Trump allegedly inflated the value of assets to apply for bank loans and deflated the same assets to avoid paying taxes.[^611]

[^611]: [What the Teapot Dome Scandal Has to Do With Trump’s Tax Returns / Brennan Center for Justice](https://www.brennancenter.org/our-work/analysis-opinion/what-teapot-dome-scandal-has-do-trumps-tax-returns). April 15, 2019

### [Trump Engaged in Suspect Tax Schemes as He Reaped Riches From His Father - The New York Times](https://www.nytimes.com/interactive/2018/10/02/us/politics/donald-trump-tax-schemes-fred-trump.html). Oct. 2, 2018

[11 Takeaways From The Times’s Investigation Into Trump’s Wealth - The New York Times](https://www.nytimes.com/2018/10/02/us/politics/donald-trump-wealth-fred-trump.html). Oct. 2, 2018

1. "The Trumps’ tax maneuvers show a pattern of deception, tax experts say"
2. "Donald Trump began reaping wealth from his father’s real estate empire as a toddler"
3. "That ‘small loan’ of \$1 million was actually at least \$60.7 million — much of it never repaid"
4. "Fred Trump wove a safety net that rescued his son from one bad bet after another"
5. "The Trumps turned an \$11 million loan debt into a legally questionable tax write-off"
6. "Father and son set out to create the myth of a self-made billionaire"
7. "Donald Trump tried to change his ailing father’s will, setting off a family reckoning"
8. "The Trumps created a company that siphoned cash from the empire"
9. "The Trump parents dodged hundreds of millions in gift taxes by grossly undervaluing the assets they would pass on"
10. "After Fred Trump’s death, his empire’s most valuable asset was an I.O.U. from Donald Trump"
11. "Donald Trump got a windfall when the empire was sold. But he may have left money on the table."

## 7. Everything Is a Transaction to Trump. Even Relationships

[Donald Trump admits EV flip-flop was a quid pro quo to secure Elon Musk’s support / Fortune](https://fortune.com/2024/08/05/donald-trump-elon-musk-tesla-endorsement/)[^711]. August 5, 2024 at 8:48 AM EDT

I questioned the mental acuity of South Carolina's Lieutenant Governor, Henry McMaster, when he endorsed Trump for president. Looking back on Trump selecting then South Carolina Governor Nikki Haley to be the US delegate to the United Nations, it makes perfect sense.

Trump: "Psst. Hey Henry, South Carolina is a early voting state and I could use a hugeliest  biggiliest, boost in your Republican primary. South Carolina is a beautiful state. You know that Obama is not American. He was born in Kenya. I own a resort in Florida. It's called Mar-a-Lago. Beautifullest golf course. I would play golf if South Carolina if I owned a golf resort here. I own a golf course in North Carolina. One of the biglyest,  bestest golf courses. Obama plays too much golf. I won't have time to play golf when I'm elected president. The PGA was going to hold a tournament there, but they canceled the tournament because of me. Can you believe that? I think I should sue the PGA. After I sue the PGA, then I'll buy it. I think that I'll buy Hilton Head. They have a bunch of golf courses. Where was I? Oh yea, I remember now. If you endose me for president, I'll make you governor of South Carolina. What do you think of this hugely idea?"[^712] McMaster: "You got yourself a deal!"

[^711]: Everything is a transaction for Trump. He *"buys"* people and disposes of them when they no longer are of value to him.
[^712]: *I tried stringing words together that don't make sense to mimic Trump’s unintelligible stream of meaningless words.* <br />I need to reset Android's spelling dictionary since Trump mangles  the English language by creating words that don't exist, adding 'ly', 'est', and 'liest', a combination of 'lt' and 'est', to words that it doesn't belong with.<br />— Ralph Hightower

## 8. Barak Obama

While Obama was president, Trump heaped a ton of shit complaining and whining continually that Obama was not an American and demand proof that he was, in fact, born in America. Trump also whined that Obama plays too much golf, which I find ironic since Trump golfs as much as possible at his golf courses.

## 9. 2016

## 10. 45th President

### International Embarrassment and Mockery

Trump adores strong-man dictators. He considers Putin of Russia and Kim Jung Un of North Korea, and China's leader as friends, while our allies are enemies.

## 11. False Election Claims

## 12. January 6, 2021

**[Doctor who punched cop during Capitol riot gets prison over the 'regrettable encounter' - Raw Story](https://www.rawstory.com/jan-6-2669138943/)**[^751]. September 5, 2024 11:52PM ET

A 71-year-old medical doctor who punched a police officer during the Jan. 6, 2021, insurrection at the U.S. Capitol apologized as she was sentenced Thursday to nine months behind bars.</></>"Jacquelyn Starer, 71, of Ashland, entered the Capitol through the Rotunda doors after attending the "Stop the Steal" rally, prosecutors said.</></>During the riot, Starer moved through the crowd and to the front of the police line. She approached the officers, pushed up against another rioter with outstretched arms, and pointed her finger in the direction of the officers. Starer then grabbed the arm of the rioter with outstretched arms and pushed it down. She then turned to face the rioter and was pushed back by a police officer."</></>"That's when Starer admitted she punched the officer with a closed fist. After moving away from the officers, she stepped towards them again, moving her hands toward the police, yelling, “F— b—!”"

[^751]: Frankly, anyone and everyone who assaulted a law enforcement officer, sprayed bear spray or other repellant at law enforcement, entered the Capitol building, vandalized federal property, assisted others in the breach and assault  should receive a multi-year sentence with no parole.<br /> — *Ralph Hightower*

## 13. Legal Troubles

1. Convicted on 34 counts of falsifying business records for hush money payments made to former adult film actor Stormy Daniels
2. Guilty of deflating property values to reduce property taxes.

## 14. Third Campaign — 2024

### [Jen Psaki Spots Ugly Sign Right-Wingers Know They're 'Probably Losing' • Huffington Post](https://www.huffpost.com/entry/jen-psaki-tim-walz-dog_n_66cd735ee4b077694c47577b)[^1401]. August 27, 2024

“They’ve now resorted to attacking the family dog,” she said. “I really wish I was joking. I am not joking.” “If you resort to attacking a candidate’s dog, you’re probably losing,” Psaki said. “And you deserve all the ridicule coming your way.” <br />“Mystery solved,” Psaki said. “Of course, this is a particularly ironic attack coming from the party whose own rising star ― you know who I’m about to talk about here, [Kristi Noem](https://www.huffpost.com/topic/kristi-noem) boasted about hating her own family dog so much she [took it to a gravel pit and shot it](https://www.huffpost.com/entry/kristi-noem-defends-shooting-dog_n_662f9dc8e4b0eb5fda50dc8c)". |

[^1401]: Personal attacks on the Waltz's family dog. ***Seriously?***

### [Trump’s psychologist niece says he’s ‘dementing’ in wake of ‘gibberish’ answer on childcare question](https://www.independent.co.uk/news/world/americas/us-politics/donald-trump-mary-childcare-dementia-b2609220.html). Sun, September 8, 2024 at 7:49 PM EDT
Gustaf Kilander

Mary Trump, the niece of Donald Trump, has shared her analysis that the former president’s mental health is deteriorating after he struggled to answer a question on childcare.

In a piece on Substack on Sunday, the psychologist argued that Trump is “dementing,” citing his appearance at the Economic Club of New York last week, where he was asked what type of legislation he would push to make childcare affordable.

“Well, I would do that, and we’re sitting down, I was somebody, we had Senator Marco Rubio, and my daughter Ivanka was so impactful on that issue,” Trump began his long, rambling answer. “It’s a very important issue, but I think when you talk about the kind of numbers that I’m talking about that because look, childcare is childcare. There’s something, you have to have it in this country, you have to have it.”

He went on to say that his proposed tariffs on imports would generate more than enough money to pay for childcare, but he did not explain what his actual policy would look like.

Mary Trump wrote that the answer was “gibberish” and the only thing that made any sense was the phrase “childcare is childcare.”

She went on to slam the “corporate media” for not properly reporting on Trump’s answer, instead thinking that “they must translate Donald’s nonsensical ramblings into a version of the English language we can all understand.”

Mary Trump argued that reporters were “imbuing” words with “meaning that is not there,” adding that it’s “deeply disturbing that somebody as unhinged and incoherent as Donald is allowed to run for the presidency in the first place.”

The psychologist wrote that her uncle is “demonstrably untethered from reality” and that “the warning lights” aren’t flashing “because nobody covering him expects otherwise.”

“Surely a political press corps that spent months arguing that President Biden’s age rendered him mentally unfit, wouldn’t look the other way when the Republican candidate, the oldest person to run for president in American history, is not only old but decompensating before our very eyes,” she wrote. “The difference of course is that Biden is aging while Donald is dementing.”

Calling him “frightened” and “desperate,” Mary Trump argued that the former president is concerned that his very freedom relies on his ability to get back into the White House and make the pending federal cases against him go away.

As she lambasted the media for its coverage of the ex-commander-in-chief, Mary Trump concluded: “The American people deserve to know what we’re up against. We deserve to be told that there’s a maniac on the loose.”

On Saturday night, the former president vowed to jail anyone “involved in unscrupulous behavior” in connection to the election in November.

“WHEN I WIN, those people that CHEATED will be prosecuted to the fullest extent of the Law, which will include long term prison sentences so that this Depravity of Justice does not happen again,” Donald Trump wrote.

He added: “Please beware, that this legal exposure extends to Lawyers, Political Operatives, Donors, Illegal Voters, & Corrupt Election Officials. Those involved in unscrupulous behavior will be sought out, caught, and prosecuted at levels, unfortunately, never seen before in our Country.”

Trump has repeatedly threatened to use the presidency to enact revenge on those he believes have wronged him despite there being no evidence of the kind of fraud that he falsely insists lost him the 2020 election.

### [Goldman Sachs report: Harris would likely boost the economy while Trump would stifle growth](https://www.salon.com/2024/09/05/goldman-sachs-report-harris-would-likely-boost-the-economy-while-would-stifle-growth/). September 5, 2024.
Story by Nicholas Liu
Former President Donald Trump has been describing President Joe Biden's administration as a disaster for the economy while presenting himself as the man who will correct course. But analysts from Goldman Sachs warn that it's Trump who would jeopardize an economic recovery with wrongheaded ideas on trade, immigration and other issues.

According to a report released by the investment bank on Tuesday and shared with several news outlets, Trump's policies, if implemented, could cut into the U.S. gross domestic product (GDP) by as much as half a percentage point in 2025 before it rebounds. Even a small decrease in GDP or just slow growth could lead to widespread unemployment, pay cuts and struggling businesses.
Related video: Harris’ sound economic policies vs. Trump’s SIX bankruptcies & tanking 'Truth' stock (MSNBC)
policies that would actually help Americans, Vice President Kamala Harris.

“We estimate that if Trump wins in a sweep or with divided government, the hit to growth from tariffs and tighter immigration policy would outweigh the positive fiscal impulse,” the report said, echoing previous warnings by economists who say that Trump's proposals to raise tariffs and cut taxes will also increase the deficit and inflation rate, not lower them as he has promised.

On the other hand, Goldman predicted that a Kamala Harris presidency and Democratic control of Congress would lead to better economic outcomes, suggesting that spending initiatives and tax credits would "more than offset" any investment slowdown caused by the higher corporate income tax rate that Harris has proposed on the campaign trail. If Harris wins but Congress is divided, the report said, policy changes would be "small" and have little to no effect on the GDP.

Either potential administration may have to deal with changed economic conditions. The Federal Reserve is expected this month to make its first interest rate cut in five years, which some economists view as a sign of confidence amid slowing inflation, while others warn it could send the wrong message about a potential recession and spook investors.

The Harris campaign was quick to capitalize on the Goldman report. “Vice President Harris has a positive vision to strengthen the economy by building up the middle class, cutting taxes and lowering costs for working families and small businesses, and creating opportunities for all Americans to get ahead," a spokesperson said in a statement. "On the economy, the choice could not be any more clear this November."

### [Jan. 6 'Awards Gala' at Trump's golf course has been postponed](https://www.msnbc.com/top-stories/latest/jan-6-awards-gala-trump-bedminster-fundraiser-rcna169320). Sept. 3, 2024, 1:03 PM EDT

By Clarissa-Jan Lim

A fundraising event for Jan. 6 defendants, which had been scheduled to take place this week at Donald Trump’s golf club in Bedminster, New Jersey, has been postponed indefinitely.

Dubbed the “J6 Awards Gala,” the event was initially scheduled for Thursday, but its website now lists the event as postponed and its location as “undetermined.”

The event had been touted as a celebration of Jan. 6 defendants and a fundraiser for their legal fees. Tickets ranged from **\$1,500 per person[^1411]** *for general admission* to **\$50,000[^1412]** for a *“platinum table”* for 12 at the VIP reception. Trump was listed as an “invited speaker” but was not expected to attend.

[^1411]: Do the Proud Boys, Oath Keepers, 3 Percenters have that kind of disposable money?
[^1412]: **50,000 dollars?!** Well, it does say **Gala**. That has to be a tuxedo event. For those prices, they should be serving Dom Perignon champagne 🍾 and Beluga caviar instead of Pabst Blue Ribbon beer 🍺 and chips.

The event’s featured guests had included some of the most notorious names in the MAGA world. Among them were former New York Mayor Rudy Giuliani, who has been indicted in Arizona and Georgia on charges of trying to help Trump steal the 2020 election (he has pleaded not guilty) and who is also dealing with the fallout from defaming two Georgia election workers; and Peter Navarro, who served a four-month sentence after being convicted of contempt of Congress for refusing to comply with a subpoena from the Jan. 6 House select committee.

The event website did not provide a reason for the postponement. Organizer L.J. Fino told Fox Business that it was because of “scheduling conflicts of invited guest speakers” and that they expect the event to take place after the November election. However, The New York Times reported Sunday that it had obtained text messages in which event planners cited “multiple issues outside of our control, the main one being safety concerns of attendees and staff.” (MSNBC has not verified the Times’ reporting.)

The decision to host an event at Trump’s golf club to honor and raise money for Jan. 6 defendants was audacious, but not entirely surprising. Trump himself is facing criminal charges over his role in the attacks (he has pleaded not guilty), and he has vowed to pardon Jan. 6 defendants if he returns to the White House, including those who assaulted police officers that day. This past Sunday, he told Fox News that he had “every right” to interfere in the 2020 election.

### [Donald Trump Hosting Jan. 6 Awards Gala Sparks Fury: 'Absolutely Horrid'](https://www.newsweek.com/donald-trump-hosting-jan-6-awards-gala-sparks-fury-absolutely-horrid-1943435). Aug 23, 2024 at 7:18 AM EDT

Story by James Bickerton

A January 6 "awards gala" is due to be hosted at Donald Trump's New Jersey golf resort, and the former president is listed as an "invited guest speaker," along with former New York mayor Rudy Giuliani.

The event, in Bedminster, has sparked outrage on social media. One former Republican White House official branded it "absolutely horrid," accusing Trump of "glorifying violence."

On January 6, 2021, hundreds of Trump supporters stormed Congress in a bid to prevent Joe Biden's 2020 presidential election victory from being certified, following a rally addressed by the then president who made discredited claims of election fraud. In the ensuing violence one demonstrator, 36-year-old Ashli Babbitt, was shot dead by police, five other deaths were linked to the mayhem, and many police and demonstrators were injured.

The gala is being organized by Stand in the Gap, a group formed to support "January 6th defendants and their families during their time in incarceration," and is being held on Thursday September 5. More than 1,200 people were charged over their alleged involvement in the Capitol riot, and more than 460 were sentenced to prison.

According to Stand in the Gap the "unforgettable evening" is being held to "honor and celebrate the twenty defendants who contributed to the powerful Justice For All song," along with "all J6 defendants who have shown incredible courage and sacrifice."

Justice For All is a song released by the January 6 Choir, which features prisoners incarcerated over their role in the chaos singing the national anthem, interspaced with Trump reciting the Pledge of Allegiance. The song briefly rose to Number 1 on the on the iTunes download chart and was played at Trump rallies across the U.S.

The gala will also function as a fundraiser, and the proceeds will provide "much needed assistance to the January 6 defendants," according to organizers.

Those attending the event will have the opportunity to win a "signed custom platinum plaque commemorating the Justice for All song," flagged by organizers as: "A rare opportunity to own a piece of history while making a significant impact on the lives of those who have shown incredible bravery and sacrifice."

While Trump is listed as an "invited guest speaker" it is unclear whether the Republican presidential candidate will be attending the event in person. Newsweek contacted Trump's 2024 presidential campaign and Stand in the Gap by email, along with the Trump National Golf Club Bedminster via online inquiry form, for comment on Friday outside of regular office hours.

News that a Trump property is hosting a January 6 "awards gala" sparked anger on social media. On X, Olivia Troye, who worked as an adviser to then Vice President Mike Pence and on the White House coronavirus task force, commented: "Trump hosting a Jan. 6 Awards Gala is absolutely horrid. Celebrating the people who endangered the life of his own Vice President & glorifying violence is a dangerous assault on our democracy & a disgraceful rewriting of history. We must all stand together against him."

Independent media outlet The Tennessee Holler shared an invite for the event adding: "This is real. He has no remorse about that dark day."

John Avlon, who is standing as the Democratic Party candidate for New York's First Congressional District, branded the event "insane."

Trump has been criminally indicted over claims he broke the law attempting to overturn the 2020 presidential election result both nationwide and in the state of Georgia specifically. He has pleaded not guilty to all charges and denies any wrongdoing.

### ['Are You Seriously This Stupid?': Legal Minds Nail Trump After Fox News 'Confession' • Huffington Post](https://www.huffpost.com/entry/donald-trump-election-interference-confession_n_66d5592ce4b0f968d26d1ba2). September 2, 2024

“Whoever heard you get indicted for interfering with a presidential election, where you have every right to do it, you get indicted, and your poll numbers go up,” he said. Trump is facing charges in multiple jurisdictions and cases, including election interference in a criminal case filed in federal court in Washington. Last week, he was reindicted to comply with directions from the Supreme Court, which in July ruled that Trump was immune from prosecution for “official acts.”

On Sunday, however, Trump flat out said he had “every right” to have been “interfering” with the election.

Lawmakers, former prosecutors, attorneys and other legal minds were ready with a fact-check ― and some said it sounded like Trump was admitting to a crime.

### [Donald Trump says he had 'every right' to interfere in election](https://thehill.com/homenews/campaign/4858494-donald-trump-election-interference-cases/). 09/02/24 08:28 AM ET

Former President Trump in an interview broadcast late Sunday argued he had “every right” to interfere with the 2020 election while repeating his claim the criminal election interference cases against him are politically motivated.

“It’s so crazy, that my poll numbers go up. Whoever heard you get indicted for interfering with a presidential election, where you have every right to do it, you get indicted, and your poll numbers go up. When people get indicted your poll numbers go down,” Trump said in an interview on Fox News’s “Life, Liberty and Levin.”

**[Trump campaign was warned not to take photos at Arlington before altercation, defense official says / AP News](https://apnews.com/article/trump-arlington-cemetery-altercation-afghanistan-3f0331e9209336a9b696ec164be7eb1c). August 27, 2024**

“Federal law prohibits political campaign or election-related activities within Army National Military Cemeteries, to include photographers, content creators or any other persons attending for purposes, or in direct support of a partisan political candidate’s campaign,” the cemetery officials’ statement said. “Arlington National Cemetery reinforced and widely shared this law and its prohibitions with all participants. We can confirm there was an incident, and a report was filed.”

### [Trump targets Harris, Walz with entirely made-up claims • MSNBC](https://www.msnbc.com/rachel-maddow-show/maddowblog/donald-trump-targets-kamala-harris-tim-walz-claims-election-2024-rcna168458).August 27, 2024

*If Kamala Harris and Tim Walz are as awful as Donald Trump claims, shouldn’t he be able to make a compelling case against them without making stuff up?*

Aug. 27, 2024, 2:19 PM EDT
By Steve Benen

At a campaign event in Arizona late last week, Donald Trump spent a predictable amount of time targeting Vice President Kamala Harris, specifically telling his supporters, “Nobody lies like her. She is a liar. She makes up crap.”

The Republican’s rhetoric was rather ironic. After all, the former president is not only the most prolific liar in recent memory, he makes stuff up on a daily basis. Indeed, minutes after insisting that the Democratic nominee “makes up crap,” Trump told the same audience that Minnesota Gov. Tim Walz “approved a bill to give tampons in every young man’s bathroom.”

In reality, Walz did no such thing. In a speech in which the GOP candidate complained about campaign dishonesty, he peddled campaign dishonesty.

Two days later, Team Trump released a campaign ad that insisted the Biden/Harris administration has “literally unleashed the IRS to harass workers who receive tips.” As a Washington Post fact-check report explained, that didn’t happen.

To recap, the Trump campaign claims Harris can’t be trusted on her no-tax tip plan because the IRS proposed a plan to streamline three programs to help employers calculate tip income. But the proposal has been shelved. So, leaving aside the exaggerations about what the proposal would do, it’s simply false to claim Harris “literally unleashed the IRS to harass workers who receive tips.”

Note, this wasn’t an off-hand and unscripted comment at a rally; the Trump campaign carefully included this specific phrasing in a paid television ad. The Republican operation almost certainly knew the claim was baseless, but the former president and his 2024 team pushed it anyway.

A day later, Trump spoke at the National Guard Association’s conference and took care to blame Harris for America’s withdrawal from Afghanistan three years ago, despite the fact that (a) it wasn’t Harris’ call, (b) Trump’s the one who negotiated the withdrawal agreement, and (c) his own White House national security adviser said Trump bears some responsibility for what transpired.

All of which leaves the political world with an awkward question: If Harris and Walz are as awful as Republicans claim, shouldn’t Trump be able to make a compelling case against them without making stuff up? Shouldn’t it be easy for the GOP nominee and his allies to stick to reality-based critiques?

Doesn't the fact that the former president has to rely so heavily on dishonesty reinforce the idea that maybe Harris and Walz aren’t so bad after all?

### [Finally, the Democrats Have Found Trump’s Achilles’ Heel: Ridicule Him / The New Republic](https://newrepublic.com/article/185270/democrats-harris-trump-achilles-heel-ridicule). August 26, 2024.

Ridicule makes him weaker. Ridicule makes him small. Ridicule makes him desperate. He’ll try to respond with ridicule of his own, but he is not a clever man. He’s a stupid man. He has no wit. He has no sense of mischief. He doesn’t read. He doesn’t think beyond first reactions. These nicknames of his, which the press has made such a big deal of over the years—they’re nothing. They’re dick contests put into words. Little Marco, Sleepy Joe. There’s nothing remotely clever about any of them.

### [Trump allies try to energize him as he struggles to adapt to Harris - The Washington Post](https://www.washingtonpost.com/politics/2024/08/24/trump-energy-campaign-harris/). August 24, 2024 at 5:02 p.m. EDT
By Isaac Arnsdorf, Josh Dawsey and Marianne LeVine

Republican nominee Donald Trump looked cheerful playing golf at his New Jersey club one day earlier this month, then appeared bored in an afternoon news conference and dour during a reception with megadonor Miriam Adelson. He publicly mused about staying home during the Democratic National Convention, letting Vice President Kamala Harris hold the spotlight unchallenged.

Cut through the 2024 election noise. Get The Campaign Moment newsletter.
Several former aides who have known Trump for years said he always preferred to keep a lighter schedule in August, when his family visited Bedminster and he usually golfed almost every day.

But aides did not want a situation where he was watching the convention every night, getting angry, and then just golfing all day and stewing, according to people who spoke on the condition of anonymity to discuss private interactions. Trump also had grown annoyed with the news coverage that depicted him as not working as hard as his opponent, one person who talked to him said.

The candidate, though, often appeared reluctant. He frequently departed from the policy themes assigned to each day’s event — an attempt to keep him focused on poll-tested messages over his pugnacious impulses — illustrating his continued struggle to find his footing in a changed race.

“The stakes for Trump this election are arguably the highest they’ve ever been. His criminal cases don’t go away if he loses. Yet he seems to be phoning it in, running a remarkably low-energy, undisciplined campaign,” said Alyssa Farah Griffin, a former White House spokeswoman who quit after Trump supporters attacked the Capitol on Jan. 6, 2021. “From spending days off the campaign trail golfing to coming up with frankly weak nicknames like ‘Kamabala,’ it feels like he’s lost his mojo.”

### [Donald Trump admits EV flip-flop was a quid-pro-quo to secure Elon Musk’s support • Fortune](https://fortune.com/2024/08/05/donald-trump-elon-musk-tesla-endorsement/). August 5, 2024 at 8:48 AM EDT

Republican presidential nominee Donald Trump admitted to tempering his strident opposition to electric vehicles in order to gain the endorsement of billionaire Elon Musk, the CEO of Tesla.

The former president, well known for the transactional nature of his politics, has championed an economic agenda relying heavily on cheap, plentiful energy through fracking and mining of U.S. fossil fuel deposits that drive climate change. Tesla’s stated mission, however, is to accelerate the world’s transition to sustainable energy.

Speaking to supporters in Atlanta, Trump now said EVs aren’t all that bad, adding they could continue being a small slice of the U.S. car market should he retake the White House.

“I’m for electric cars. ***I have to be, you know, because Elon Musk endorsed me very strongly,”*** he said in comments shared widely throughout Musk’s fan base by accounts like John Stringer’s Tesla Owners Silicon Valley and blogsite Teslarati. “So I have no choice.”

Last month the New York real estate mogul pledged to roll back President Biden’s EV subsidies, which he labeled a “green new scam,” on day one of a second Trump administration.

Speaking to Maria Bartiromo on Thursday, Trump explained all the electric cars of the future will be made in China, since the United States doesn’t have the mineral resources of its rival, the world market leader in processing battery-grade lithium.

“They don’t go far, [and] they cost too much,” he said, referring to EVs. “I like Tesla, but you know what? It’s limited.”

His vice presidential pick, JD Vance, meanwhile, has pushed a bill called the Drive American Act that would repeal Biden’s $7,500 federal tax credit for EVs and hand it instead to conventional combustion engine cars.

This has put Musk on the back foot, forcing the EV champion to claim late last month Trump’s hostility to EVs would harm his competition more than it would Tesla itself.

Musk’s brand sells roughly as many EVs in the U.S. as all its other competitors combined. Along with China’s BYD, it is one of the only two carmakers in the world to build EVs profitably at scale.

### [Musical Acts Who've Called Out 2024 Trump Campaign for Illegal Use of Their Songs • Hollywood Reporter](https://www.hollywoodreporter.com/news/politics-news/muscial-acts-trump-campaign-illegal-use-songs-1235988369/)[^1499]. August 31, 2024.
- ABBA (2024) — More than 40 years after ABBA disbanded, their music is still everywhere, whether you’re catching their high-tech hologram residency or rewatching the 2008 cinematic classic Mamma Mia! — or, apparently, if you’re in the audience at a Trump rally. At a July 27 event in St. Cloud, Minnesota, Trump’s campaign played several ABBA hits (“Dancing Queen,” “Money, Money, Money,” “The Winner Takes It All”), and even showed video footage of the Swedish pop greats. Shock of shocks: They did not have permission for any of this, and Björn Ulvaeus and the group’s label have demanded that Trump stop immediately. —S.V.L.
- Beyoncé (2024) — While most complaints have focused on music played at Trump rallies, Beyoncé and her team issued a cease-and-desist letter after a Trump campaign spokesperson used her song “Freedom” in a short video shared online. The clip paired the Lemonade track with a 13-second clip of Trump getting off an airplane — a pretty pointed choice as “Freedom” has become an unofficial anthem of sorts for the Kamala Harris campaign. While Beyoncé did give the Harris campaign permission to use the song, a source close to the musician told Rolling Stone they “absolutely did not give permission” to Trump campaign, and that Bey’s label had threatened to issue a cease and desist. —J.B.
- Isaac Hayes’ Family (2024) — The family of late soul singer Isaac Hayes wants to stop Trump from playing the hit “Hold On, I’m Comin’” at rallies and events, including at an NRA convention. Hayes’ son, Isaac Hayes III, shared that they planned to file a lawsuit after learning that the Trump team has used the song about 135 times without licensing the song or asking for permission. “I was pissed,” Hayes told The Hollywood Reporter. “There’s just been a mass shooting. So why are we using it at the NRA convention? I wanted to take legal action because Trump has made statements against women, and here is a man who has been convicted of sexual abuse. I’m a brother to seven sisters, and I don’t want anybody to think of ‘Hold On’ and think of Donald Trump.” —J.L.
- Phil Collins (2020) — MAGA energy was not in the air when Phil Collins made “In the Air Tonight.” The musician issued a cease-and-desist to Trump for usage of his 1981 single during the 2020 election. In the letter sent to Trump, Collins slammed the candidate for using the song “as a satirical reference to Covid-19” when Iowa was going through a spike in cases. “Mr. Collins does not condone the apparent trivialization of Covid-19,” the letter stated, adding that the musician had “serious concerns” that Trump’s usage would “damage” Collins’ reputation. —T.M.
- Sinéad O’Connor’s Estate (2024) — Sinead O’Connor’s estate quickly shut Trump down when he started using the late singer’s song “Nothing Compares 2 U” at his rallies in Maryland and North Carolina. “It is no exaggeration to say that Sinéad would have been disgusted, hurt, and insulted to have her work misrepresented in this way by someone who she herself referred to as a ‘biblical devil,’” O’Connor’s estate representatives shared in a statement to Variety. “As the guardians of her legacy, we demand that Donald Trump and his associates desist from using her music immediately.” —J.L.
- Céline Dion (2024)<br />Céline Dion was not happy when Donald Trump used her Titanic classic “My Heart Will Go On” at a recent campaign rally. “And really, THAT song?” she wrote on social media when she learned he’d been playing the hit. The Canadian star’s team issued a statement on Aug. 10 slamming the former president for “unauthorized usage” of the track from the Nineties film. “Celine Dion does not endorse this or any similar use,” the statement from Dion’s team said.<br />The family of James Horner, the song’s composer who died in 2015, also said in a statement that “the Horner family does not endorse or support the Trump/Vance campaign or its use of the song at its events. The campaign does not reflect the beliefs and values of James Horner or his family. It is important to the family that his music not be used by those seeking to profit inappropriately from his work after his death.” —T.M.
- John Fogerty (2020) — Unsurprisingly, Trump — the son of a multimillionaire who got out of Vietnam due to supposed bone spurs — saw nothing ironic about playing John Fogerty’s “Fortunate Son” (“I ain’t no millionaire’s son, no”) at his campaign rallies in 2020. Fogerty and his lawyers immediately told him to stop via a cease-and-desist letter. “I wrote this song because, as a veteran, I was disgusted that some people were allowed to be excluded from serving our country because they had access to political and financial privilege,” Fogerty said. “I also wrote about wealthy people not paying their fair share of taxes. Mr. Trump is a prime example of both of these issues.” —A.G.
- Journey’s Neal Schown (2022) — When Journey guitarist Neal Schon sent a cease-and-desist letter over a performance of “Don’t Stop Believin’,” he actually wasn’t targeting Trump so much as his bandmate Jonathan Cain. Cain had performed the 1981 hit at Mar-a-Lago in 2023, alongside backup singers that included Marjorie Taylor Greene, Kimberly Guilfoyle, and Kari Lake. In order to prevent similar moments, Schon filed the cease-and-desist, stating the use of Journey’s music at a Trump event was of “harmful use” to their brand. —J.B.
- Foo Fighters (2024) — Trump angered the Foo Fighters when “My Hero” started playing at a rally in Arizona in August. The song came on just as Robert F. Kennedy Jr. joined the former president onstage to announce he was ending his campaign and endorsing Trump. Asked via social media if they had approved this, the band replied “No.” A rep for the band later confirmed that the Foo Fighters didn’t give Trump permission to use the song, and added that royalties from its use at the event would be donated to the Harris-Walz campaign. —D.K.
- Johnny Marr (2024) — While the Smiths might seem wildly out of place at a Trump rally, the camp certainly tried it. In early 2024, multiple political reporters took to Twitter to share how the hopelessly desperate “Please, Please, Please, Let Me Get What I Want” was making its rounds with MAGA folks. Founding guitarist and the song’s writer, Johnny Marr, immediately responded when he quote-tweeted a video saying, “Ahh … right … OK. I never in a million years would’ve thought this could come to pass. Consider this shit shut right down right now.” —M.G.
- Tom Petty’s Estate (2020)  — The Florida rocker had a history of sending cease-and-desist letters to politicians using his music, including George W. Bush in 2000 (“I Won’t Back Down”) and Minnesota congresswoman Michele Bachmann in 2011 (“American Girl”). Three years after his death, his family spoke out about a certain Florida Man’s use of “I Won’t Back Down,” writing that Trump “was in no way authorized to use this song to further a campaign that leaves too many Americans and common sense behind.” His family continued, “Tom wrote this song for the underdog, for the common man and for EVERYONE.… We believe in America and we believe in democracy. But Donald Trump is not representing the noble ideals of either.” Amen to that. —A.M.
- R.E.M. (2015) — Maybe if R.E.M.’s “It’s the End of the World as We Know It” didn’t come with the parenthetical “(And I Feel Fine),” they wouldn’t have complained about Trump using the song on the campaign trail in 2015. Regardless, all was not fine and Michael Stipe issued a stern rebuke to the Trump campaign for using the song: “Go fuck yourselves, the lot of you — you sad, attention-grabbing, power-hungry little men. Do not use our music or my voice for your moronic charade of a campaign.” —K.G.
- Rihanna (2018) — Just after Trump played Rihanna’s 2007 hit “Don’t Stop the Music” at a rally in Chattanooga, Tennessee, her team sent him a cease-and-desist letter threatening legal action. “It has come to our attention that President Trump has utilized [Rihanna‘s] musical compositions and master recordings, including her hit track ‘Don’t Stop the Music,’ in connection with a number of political events held across the United States,” Rihanna’s legal team wrote in the letter. “As you are or should be aware, Ms. Fenty has not provided her consent to Mr. Trump to use her music. Such use is therefore improper.” —J.L.
- The Rolling Stones (2020) — he Rolling Stones made a pun out of one of their own song titles in 2020 when they told the Trump campaign to stop using their songs: “This could be the last time Trump uses any Jagger-Richards songs on his campaigns,” the band’s rep said at the time. Trump had been using “You Can’t Always Get What You Want” at rallies. Apparently, he wanted threats of legal action. —K.G.
- Village People (2023) — Trump’s love of the Village People is well-documented. For years, he played  “Y.M.C.A.” and “Macho Man” at his rallies with little pushback from founding member Victor Willis. Willis finally changed his tune in June 2020 amid the uprising against racial injustice. Then, in May 2023, he sent Trump’s legal team a cease-and-desist letter after video emerged of the former president at Mar-a-Lago dancing along to “Macho Man” with a group dressed up like the Village People. Willis called the performance “unauthorized” and noted that “many fans, and the general public as well, mistakenly believe” the actual Village People delivered the performance. —J.B.
- Steven Tyler (2018) — Donald Trump was living on the edge of a lawsuit in 2018 when Aerosmith’s Steven Tyler felt it was necessary to send a cease-and-desist letter to the then-president’s campaign for using the song “Livin’ on the Edge.” This came three years after the band already told Trump to knock it off with playing “Dream On” at rallies. —K.G.
- Jack White (2024) — Since its release on 2003’s Elephant, the White Stripes’ “Seven Nation Army” has been sung and chanted at countless sporting events around the world. It’s as close as you can get to a universal jock jam like “We Will Rock You” — but that doesn’t mean Jack White is cool with someone like Trump using it. When MAGA campaign flack Margo Martin shared a video of the candidate boarding a plane to that iconic riff, White snapped back. “Don’t even think about using my music you fascists,” he wrote.  “Lawsuit coming from my lawyers about this (to add to your 5 thousand others).” We assume that applies to the pretty dang awesome new album he released this summer, too. —S.V.L.
- Neil Young (2020) — Neil Young’s spat with Trump dates back all the way to 2015, when Trump played “Rockin’ in the Free World” immediately after announcing his plan to run for president. Young, unsurprisingly, was not happy and repeatedly expressed his discontent when the song played at Trump rallies over the coming years. Eventually, in 2020, Young tried suing Trump, claiming he did not have a proper license to play his music at his rallies. But a few months later, the musician ultimately chose to voluntarily dismiss the complaint. —J.B.

[^1499]: Sure, it’s not uncommon for politicians to use popular songs at events and campaign rallies — but lots of artists have drawn the line when it comes to Donald Trump. Since the former president began campaigning ahead of the 2016 election, some musicians have not been happy to hear that the Trump team has played their music, often without authorization. From Canadian singer Céline Dion to the family of soul icon Isaac Hayes, they’ve done everything from issuing public statements to sending cease-and-desist letters to Trump through lawyers.

## 15. Manifesto — Heritage Foundation & Trump

### [Project 2025](https://en.wikipedia.org/wiki/Project_2025?wprov=sfla1) — A Pathway to Autocracy

### [Agenda 47](https://en.wikipedia.org/wiki/Agenda_47?wprov=sfla1)

## 16. Other Op-Ed

### An Analysis of Trump's Myriad of Flaws by a Right-Winger Opinion Writer[^1601]. Nicole Russell, USA Today.

[Nicole Russell](https://www.usatoday.com/staff/73221959007/nicole-russell/)[^1601] points out the many faults and flaws of Trump, but she thinks that the election is winnable if and only if Trump acts like an adult instead of the man-child, school yard bully, and crybaby.

*Bless her heart.*<br />
*– Ralph Hightower*

[^1601]: Nicole Russell is an opinion columnist with USA TODAY. She lives in Texas with her four kids.

[Trump is losing a winnable election. He has no one to blame but himself.](https://www.usatoday.com/story/opinion/columnist/2024/08/25/trump-harris-2024-election/74863488007/). August 25, 2024

- Trump is behind because he lacks discipline
    - Trump's biggest obstacle is Trump
        -  Reporting on a news conference is a nightmare because Trump cannot commit to the self-discipline that it takes to prepare ahead of time, pare his thoughts to a handful of strong talkingl points and then cogently answer questions on what his administration would look like.
        - Trump insists on coming across like a moron. His thoughts and ideas flow with a stream of consciousness that makes William Faulkner look like a children's nursery rhyme. He jumps from idea to idea like a hip-hop artist doing a break dancing routine at the Olympic level.
        - When he talks about his record or his plans for a second term, it's a jumbled, garbled mess of word salad.
- Trump loves himself more than he loves America
    - Trump also is behind because he loves himself more than he really loves America. 
        - The former president's campaign is mostly focused on himself. It's not really about making America great again. It's more about pumping up Trump's already overinflated ego.
        - Trump's personality doesn't allow him to accept advice or learn from his mistakes. Only people who accept responsibility for their behavior can find the courage to ask for help and really listen to it.
- Trump is incredibly self-absorbed.
    - Even after nearly being killed, Trump went back to posting rants on Truth Social like a 9-year-old boy having a Trumper Tantrum.
        - Instead of being disciplined, strategic and precise[^1611], he's flailing. He's frenetic, mean and boastful[^1612].
- Trump's own history haunts him
    - Trump's character flaws, including his sordid history with women and his many legal troubles. Those are the things that come to people's minds when they see Trump's name flash across their television screen
        - Trump has been indicted in four criminal cases and found guilty in his hush money conviction that warranted a felony, concealing the bribery as a business expense. He still demonstrates patterns of making poor choices and skirting the law.
        - Trump has repeatedly behaved like a misogynist. He has been dishonest when he should have told the truth. He has not lived in a manner befitting a U.S. president. Those flaws have repulsed many Americans.
- Trump is behind because he can't focus on Harris
    - Trump's biggest pitfall is his inability to focus on his opponent in any serious way.
        - Trump loses focus. The next thing you know he's recalling a moment he had at Mar-a-Lago with Chinese President Xi Jinping on a "beautiful sofa."
        - Trump's inability to stay on point while speaking fits within a larger pattern of being unable to spend significant amounts of time and energy focused.

[^1611]: Surely, you jest. The only time that Trump is strategic is whe he's working on his next con game. — *Ralph Hightower*
[^1612]: Nicole, honey, Trump ain't gonna change from being deceitful, mean, and boastful, also conceited. 

## 17. [Presidential Rankings Survey - Historians Rank the Top 10 Presidents / C-SPAN Survey on Presidents 2021](https://www.c-span.org/presidentsurvey2021/?page=overall)

### Donald Trump's Rankings[^1701]

| Category	| 2021 Final Score	| Overall Rankings 2021	|
|---|---|---|
| Public Persuasion	| 43.9 | 32 |
| Crisis Leadership	| 26.5 | 41 |
| Economic Management |	42.7 | 34 |
| Moral Authority	| 18.7 | 44[^1701] |
| International Relations |	33.3 |	43 |
| Administrative Skills	| 22.8	| 44 |
| Relations with Congress |	28.6 | 42 |
| Vision / Setting an Agenda	| 39.6 | 36 |
| Pursued Equal Justice For All	| 27.6 | 40 |
| Performance Within Context of Times	| 28.3	| 42 |

[^1701]: Interestingly, Donald Trump ranks dead last in the category of Moral Authority.

Overall, Trump ranks 41 of 44, above Franklin Pierce (42),  Andrew Johnson (43), and James Buchanan (44)

## A. Definitions

###  [Acolyte — Merriam-Webster](http://www.merriam-webster.com/dictionary/acolyte)

noun<br />ac·​o·​lyte <br />\ ˈa-kə-ˌlīt , -kō- \<br />Definition<br />1: one who assists a member of the clergy in a liturgical service by performing minor duties<br />2: one who attends or assists a leader : follower<br />//The mayor dined with a few of his acolytes.<br />Synonyms & Antonyms<br />Synonyms adherent, convert, disciple, epigone, follower, liege man, partisan (also partizan), pupil, votarist, votary<br />Antonyms coryphaeus, leader<br />Examples<br ///a popular professor dining with a few of her acolytes<br />//a highly influential economist whose acolytes can be found at many major universities<br />First Known Use<br />14th century, in the meaning defined at sense 1<br />History and Etymology<br />Middle English acolite, borrowed from Anglo-French & Medieval Latin; Anglo-French acolit, borrowed from Medieval Latin acolūthus, acolythus, acolitus, going back to Late Latin, "person assisting the priest," borrowed from Middle Greek akólouthos, going back to Greek, "following, (as noun) follower, attendant," from a- (variant, before a following aspirate consonant, of ha- "having one, having the same," going back to Indo-European sm̥-) + -kolouthos (ablaut form, in a compound, of kéleuthos "path"); akin to Greek heîs "one," homós "same" and perhaps to Greek keleúein "to direct forward, urge on" — more at same entry 1, hold entry 1

### [Sycophant — Merriam-Webster](http://www.merriam-webster.com/dictionary/sycophant)

noun<br />sy·​co·​phant <br /> \ ˈsi-kə-fənt , also ˈsī-, -ˌfant \<br />Definition<br />: a servile self-seeking flatterer<br />Other Words<br />sycophant adjective<br />Synonyms & Antonyms<br />Synonyms apple-polisher, bootlicker, brownnoser, fawner, flunky (also flunkey or flunkie), lickspittle, suck-up, toady<br />Examples<br />//be careful not to mistake sycophants for true friends<br />First Known Use<br />1575, in the meaning defined above<br />History and Etymology<br />borrowed from Latin sȳcophanta, borrowed from Greek sȳkophántēs, literally, "one who shows the fig," from sŷkon "fig" (perhaps in reference to an apotropaic gesture made by inserting the thumb between the index and second fingers) + -phantēs, agentive derivative of phaínein "to reveal, show, make known"; perhaps from the use of such a gesture in denouncing a culprit — more at fig entry 1, fantasy entry 1<br />NOTE: The origin of Greek sȳkophántēs, applied in ancient Athens to private individuals who brought prosecutions in which they had no personal stake, was already under debate by ancient writers. The "apotropaic gesture" hypothesis given here was presented early on by Arthur Bernard Cook ("CΥΚΟΦΑΝΤΗC," The Classical Review, vol. 21, issue 5 [August, 1907], pp. 133-36); Cook also usefully summarizes ancient speculation (as the idea that the original sȳkophántēs denounced those who illegally exported figs from Attica). The objection has been made that the basic notion "one who makes the fig gesture" does not account for the extremely negative connotations of the word ("slanderer, calumniator, etc."), but other explanations (as, for example, that a sȳkophántēs revealed figs hidden in a malefactor's clothing, or initiated a prosecution for something of as little value as a fig) seem even less likely. A more nuanced, if not entirely convincing account, based on presumed fig metaphors in Athenian culture, is in Danielle Allen, The World of Prometheus: The Politics of Punishing in Democratic Athens (Princeton University Press, 2000), p. 156 passim. — The application of sycophant to a flatterer, which departs entirely from the Greek meaning, is peculiar to the history of the word in English. In the sixteenth century English writers seem to have applied sycophant in particular to slanderous accusers who had found their way into the retinue of the powerful. Once the word became a generally used label for ill-willed people close to those in power, it presumably became associated with obsequious flattery, a stereotypical negative quality of such people.

###  [Nepotism — Merriam-Webster](http://www.merriam-webster.com/dictionary/nepotism)

noun<br />nep·​o·​tism <br > \ ˈne-pə-ˌti-zəm  \<br />Definition<br />: favoritism (as in appointment to a job) based on kinship<br />//accused the company of fostering nepotism in promotions<br />Other Words<br /nep​o​tis​tic \ ˌne-pə-ˈti-stik  \ adjective<br />Examples<br />//Nepotism has hurt the company.<br />First Known Use<br />1670, in the meaning defined above<br />History and Etymology<br />French népotisme, from Italian nepotismo, from nepote nephew, from Latin nepot-, nepos grandson, nephew — more at nephew

### [Cronyism — Merriam-Webster](http://www.merriam-webster.com/word-of-the-day/2024/09/03/)

What It Means<br />Cronyism is the unfair practice by a powerful person (such as a politician) of giving jobs and other favors to friends without regard for their qualifications.<br /><br />// City residents are pushing back against cronyism and corruption in their local government.<br /><br />See the entry ><br /><br />Examples:<br />“Expertise, not cronyism, is needed to determine which strategies are most likely to lead to meaningful gains.” — Time, 23 Aug. 2023<br />Did you know?<br />The word cronyism evolved in the 19th century as a spin-off of crony, meaning “friend” or “pal.” In its younger days, cronyism simply meant “friendship,” or “the ability to make friends.” The word didn’t turn bad until the next century, when Americans starting using it to refer to the act of playing political favorites. If cronyism is new to your vocabulary, perhaps you’re more familiar with the related term nepotism, meaning “favoritism based on kinship, especially in professional and political contexts.”
