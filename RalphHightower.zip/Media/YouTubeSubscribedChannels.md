---
layout: page
title: Media/YouTube Subscribed Channels
#permalink: /Media/
---

[^11]: These are the [YouTube](https://youtube.com/) channels that I subscribe to. 
[^12]: I don't list the content that is listed in *"- Topics"*. It must be the band or artist. 

| Content Creator | Content Classification | Date Added/ Updated |
|---|---|---|
| [Foxwood Astronomy - YouTube](https://www.youtube.com/channel/UCgNYyqACs4Mbqpm5BIaiwgA#bottom-sheet ) | Astronomy — Solar Eclipse |
| [Sam Mahdavi](https://youtube.com/@sammahdavi7031 ) | Auto Repair |
| [Scotty Kilmer](https://youtube.com/@scottykilmer ) | Auto Repair |
| [Oliver the Beagle](https://youtube.com/@OlivertheBeagle ) | Beagles |
| [Sarah -n- Tuned](https://youtube.com/@SarahnTuned ) | Cars |
| [savagegeese](https://youtube.com/@savagegeese ) | Cars |
| [Chevrolet](https://youtube.com/@Chevrolet ) | Cars/Trucks |
| [Edmunds Cars](https://youtube.com/@edmundscars ) | Cars/Trucks |
| [Crosstalk Solutions](https://youtube.com/@CrosstalkSolutions ) | Computer Networking |
| [Ubiquiti](https://youtube.com/@UbiquitiInc ) | Computer Networking |
| [Arm Software Developers](https://youtube.com/@ArmSoftwareDevelopers ) | Computers |
| [Computerphile](https://youtube.com/@Computerphile ) | Computers |
| [Dave Plummer's Attic](https://youtube.com/@davepl? ) | Computers |
| [Dave Plummer's Garage](https://youtube.com/@DavesGarage? ) | Computers |
| [ExplainingComputers](https://youtube.com/@ExplainingComputers ) | Computers |
| [Jeff Geerling](https://youtube.com/@JeffGeerling ) | Computers |
| [Level 2 Jeff](https://youtube.com/@Level2Jeff? ) | Computers | 2024-05-10 |
| [O'Reilly](https://youtube.com/@oreilly ) | Computers |
| [RISC-V International](https://youtube.com/@RISCVInternational ) | Computers |
| [ServeTheHome](https://youtube.com/@ServeTheHomeVideo? ) | Computers |
| [Veronica Explains](https://youtube.com/@VeronicaExplains? ) | Computers |
| [Arduino](https://youtube.com/@Arduino ) | Computers – Single Board |
| [Computer History Museum](https://youtube.com/@ComputerHistory? )</br>We create and provide Educational and Historical video presentations on COMPUTER HISTORY and vintage technology, including restored footage with commentary, for educational purposes, user comment and discussion. Our channel is an independent educational research activity and our goal is to help make computer history data accessible to everyone. | Computer History |
| [GitHub](https://youtube.com/@GitHub ) | Developer Platform |
| [mrandrewcotter](https://youtube.com/@mrandrewcotter ) | Dogs |
| [Off Leash K9 Columbia, SC LLC](https://youtube.com/@offleashk9columbiascllc626 ) | Dogs |
| [SmarterEveryDay](https://youtube.com/@smartereveryday ) | Education |
| [Smithsonian National Air and Space Museum](https://youtube.com/@airandspace ) | Education |
| [South Carolina Gamecocks](https://youtube.com/@GamecocksOnline ) | Education |
| [University of South Carolina](https://youtube.com/@UofSC ) | Education |
| [Fran Blanche](https://youtube.com/@FranLab ) | Electronics |
| [Geerling Engineering](https://youtube.com/@GeerlingEngineering ) | Electronics |
| [Jeri Ellsworth](https://youtube.com/@jeriellsworth ) | Electronics |
| [Shanks FX](https://youtube.com/@ShanksFX1 ) | Electronics |
| [SparkFun Electronics](https://youtube.com/@sparkfun ) | Electronics |
| [jeffostroff](https://youtube.com/@jeffostroff ) | Engineering / Tools |
| [Practical Engineering](https://youtube.com/@PracticalEngineeringChannel? ) | Engineering | 2028-05-03 |
| [Paramount Pictures](https://youtube.com/@paramountpictures ) | Entertainment |
| [Warner Bros. Entertainment](https://youtube.com/@warnerbrosentertainment ) | Entertainment |
| [Publix](https://youtube.com/@Publix ) | Food |
| [bitluni](https://youtube.com/@bitlunislab ) | Hardware/Software |
| [Lexington Medical Center](https://youtube.com/@LexingtonMedical ) | Healthcare |
| [It's a Southern Thing](https://youtube.com/@ItsaSouthernThing ) | Humor |
| [KatieGoodman](https://youtube.com/@broadcomedy ) | Humor |
| [MyHarto](https://youtube.com/@Harto ) | Humor |
| [Saturday Night Live](https://youtube.com/@SaturdayNightLive ) | Humor |
| [MabeInAmerica](https://youtube.com/@MabeInAmerica ) | Humor — Pranking Telemarketers |
| [Aerosmith](https://youtube.com/@aerosmith ) | Music |
| [Allman Brothers on MV](https://youtube.com/@allmanbrothersmv ) | Music |
| [Ally The Piper](https://youtube.com/@PiperAlly ) | Music |
| [Ana Popovic Music](https://youtube.com/@AnaPopovicMusic ) | Music |
| [Arlo Guthrie](https://youtube.com/@ArloGuthrieRSR ) | Music |
| [BlondieMusicOfficial](https://youtube.com/@BlondieMusicOfficial ) | Music |
| [Blue Man Group](https://youtube.com/@bluemangroup ) | Music |
| [BLUE OYSTER CULT](https://youtube.com/@BLUEOYSTERCULTofficial ) | Music |
| [Bruce Springsteen](https://youtube.com/@brucespringsteen ) | Music |
| [Cars, The — Official](https://youtube.com/@TheCarsOfficial ) | Music |
| [ClarenceClemonsVEVO](https://youtube.com/@ClarenceClemonsVEVO ) | Music |
| [Creedence Clearwater Revival](https://youtube.com/@TheOfficialCCR ) | Music |
| [Deep Purple Official](https://youtube.com/@DeepPurpleOfficial ) | Music |
| [Dexys and Dexys Midnight Runners Official](https://youtube.com/@dexysofficial ) | Music |
| [Dire Straits](https://youtube.com/@direstraitsofficial ) | Music |
| [ELO](https://youtube.com/@elo ) | Music |
| [enyatv](https://youtube.com/@enyatv ) | Music |
| [Eric Clapton](https://youtube.com/@ericclapton ) | Music |
| [europethebandtv](https://youtube.com/@europethebandtv ) | Music |
| [Fleetwood Mac](https://youtube.com/@fleetwoodmac ) | Music |
| [Gordon Lightfoot](https://youtube.com/@GordonLightfootOfficial ) | Music |
| [Grateful Dead](https://youtube.com/@gratefuldead ) | Music |
| [Hootie & the Blowfish](https://youtube.com/@hootieandtheblowfish ) | Music |
| [Jackson Browne](https://youtube.com/@jacksonbrowneofficial ) | Music |
| [Janis Joplin](https://youtube.com/@janisjoplin) | Music |
| [Jefferson Airplane](https://youtube.com/@jeffersonairplane ) | Music |
| [Jefferson Starship](https://youtube.com/@JeffersonStarship ) | Music |
| [JGeilsBandVEVO](https://youtube.com/@JGeilsBandVEVO ) | Music |
| [Jim Messina](https://youtube.com/@jimmessina2808 ) | Music |
| [John Fogerty](https://youtube.com/@JohnFogerty ) | Music |
| [John Mellencamp](https://youtube.com/@JohnMellencampDotCom ) | Music |
| [KatrinaTheWavesVEVO](https://youtube.com/@KatrinaTheWavesVEVO ) | Music |
| [Kenny Loggins](https://youtube.com/@KennyLoggins ) | Music |
| [Led Zeppelin](https://youtube.com/@ledzeppelin? ) | Music |
| [Linda Ronstadt](https://youtube.com/@lindaronstadtmusic ) | Music |
| [Manfred Manns Earth Band (MMEB)](https://youtube.com/@ManfredMannOfficial ) | Music |
| [Meat Loaf](https://youtube.com/@RedPony2 ) | Music |
| [Melissa Etheridge](https://youtube.com/@melissaetheridge ) | Music |
| [Moody Blues, The](https://youtube.com/@MoodyBluesToday ) | Music |
| [Pink Floyd](https://youtube.com/@pinkfloyd ) | Music |
| [PinkFloydClassics](https://youtube.com/@pinkfloydclassics7044 ) | Music |
| [Playing For Change](https://youtube.com/@PlayingForChange ) | Music |
| [PocoVEVO](https://youtube.com/@PocoVEVO ) | Music |
| [Pretenders](https://youtube.com/@ThePretenders ) | Music |
| [remhq](https://youtube.com/@remhq ) | Music |
| [Rush](https://youtube.com/@rush ) | Music |
| [Santana](https://youtube.com/@santana? ) | Music |
| [Sheryl Crow](https://youtube.com/@Sherylcrow ) | Music |
| [sina-drums](https://youtube.com/@sina-drums ) | Music |
| [Taj Mahal](https://youtube.com/@TajMahalMusic ) | Music |
| [Traveling Wilburys](https://youtube.com/@TravelingWilburysOfficial ) | Music |
| [Virgin Rock](https://youtube.com/@VirginRock ) | Music |
| [YOYOKA](https://youtube.com/@yoyoka_soma ) | Music |
| [ZZ Top](https://youtube.com/@zztop ) | Music |
| [yesofficial](https://youtube.com/@yesofficial ) | Music  |
| [alyankovic](https://youtube.com/@alyankovic ) | Music Parody |
| [OK Go](https://youtube.com/@okgo ) | Music – Rube Goldberg Music Videos |
| [FITSNews](https://youtube.com/@FitsTube ) | News |
| [Adobe Photoshop Lightroom](https://youtube.com/@Lightroom ) | Photography |
| [Adorama](https://youtube.com/@Adorama ) | Photography |
| [Analog Process](https://youtube.com/@AnalogProcess ) | Photography |
| [Art of Photography, The](https://youtube.com/@theartofphotography ) | Photography |
| [B&H Event Space](https://youtube.com/@bheventspace ) | Photography |
| [B&H Photo Video](https://youtube.com/@BandH ) | Photography |
| [Becki and Chris](https://youtube.com/@BeckiandChris ) | Photography |
| [Ben Eater](https://youtube.com/@BenEater ) | Photography |
| [Ben Horne](https://youtube.com/@BenHorne ) | Photography |
| [Benjamin Jaworskyj](https://youtube.com/@learnfromben ) | Photography |
| [Beyond Photography](https://youtube.com/@BeyondPhotography ) | Photography |
| [Bite Shot, The](https://youtube.com/@TheBiteShot ) | Photography |
| [broncolor](https://youtube.com/@broncolorworld ) | Photography |
| [Canon Imaging Plaza](https://youtube.com/@canonimagingplaza ) | Photography |
| [Canon USA](https://youtube.com/@CanonUSA ) | Photography |
| [Canon USA Support](https://youtube.com/@CanonUSASupport? ) | Photography |
| [Charleston Center for Photography](https://youtube.com/@CCforP ) | Photography |
| [Chase Jarvis](https://youtube.com/@ChaseJarvis ) | Photography |
| [COOPH](https://youtube.com/@TheCooph ) | Photography |
| [CreativeLive](https://youtube.com/@creativelive ) | Photography |
| [Datacolor Spyder](https://youtube.com/@DatacolorSpyder ) | Photography |
| [DedoWeigertFilm](https://youtube.com/@DedoweigertfilmDe ) | Photography |
| [Elia Locardi](https://youtube.com/@EliaLocardi ) | Photography |
| [Filmmaker IQ](https://youtube.com/@FilmmakerIQ ) | Photography |
| [FilmPhotographyProject](https://youtube.com/@FilmPhotographyProject ) | Photography |
| [Fix Old Cameras](https://youtube.com/@FixOldCameras ) | Photography |
| [Fstoppers](https://youtube.com/@FStoppers ) | Photography |
| [Gary Fong Channel, The](https://youtube.com/@GaryfongInc ) | Photography |
| [Glyn Dewis](https://youtube.com/@glyndewis ) | Photography |
| [Helen Bradley](https://youtube.com/@HelenBradley ) | Photography |
| [IAmTimCorey](https://youtube.com/@IAmTimCorey ) | Photography |
| [Japan Camera Hunter](https://youtube.com/@japancamerahunter ) | Photography |
| [John Lehmann](https://youtube.com/@JohnLehmannPhotography ) | Photography |
| [Kai W](https://youtube.com/@KaiManWong ) | Photography |
| [KEH Camera](https://youtube.com/@KEHcamera ) | Photography |
| [KelbyOne](https://youtube.com/@KelbyOne ) | Photography |
| [Kodak](https://youtube.com/@Kodak ) | Photography |
| [Lensrentals](https://youtube.com/@lensrental ) | Photography |
| [Lok Cheung](https://youtube.com/@TheLokCheung ) | Photography |
| [Lonely Speck](https://youtube.com/@LonelySpeck ) | Photography |
| [Mads Peter Iversen](https://youtube.com/@MadsPeterIversen ) | Photography |
| [Marc Silber](https://youtube.com/@marcsilber ) | Photography |
| [Mark Wallace](https://youtube.com/@MarkWallaceVideos ) | Photography |
| [Mat Marrash](https://youtube.com/@MatMarrash ) | Photography |
| [Mathieu Stern](https://youtube.com/@MathieuStern ) | Photography |
| [Matt Granger](https://youtube.com/@mattgranger ) | Photography |
| [Michael Sasser](https://youtube.com/@MichaelSasser ) | Photography |
| [Michael's Photo Tips](https://youtube.com/@Smokingstrobes ) | Photography |
| [Mike Browne](https://youtube.com/@MikeBrowne ) | Photography |
| [Moose Peterson](https://youtube.com/@MoosePeterson ) | Photography |
| [NatureTTL](https://youtube.com/@Naturettl ) | Photography |
| [NBP Retouch Tools & Tutorials](https://youtube.com/@ninobatista ) | Photography |
| [Nigel Danson](https://youtube.com/@NigelDanson ) | Photography |
| [Nikon USA](https://youtube.com/@nikonusa ) | Photography |
| [Old Cameras](https://youtube.com/@OldCameras ) | Photography |
| [Photo Throwdown](https://youtube.com/@Photothrowdown ) | Photography |
| [PIXEL VIILAGE](https://youtube.com/@PIXELVIILAGE ) | Photography |
| [PlustekGlobal](https://youtube.com/@PlustekGlobal ) | Photography |
| [PRO EDU Photography Tutorials](https://youtube.com/@proedututorials ) | Photography |
| [Rolling Vistas](https://youtube.com/@RollingVistas753 ) | Photography |
| [Sandra Coan](https://youtube.com/@SandraCoan ) | Photography |
| [Sara Dietschy](https://youtube.com/@saradietschy ) | Photography |
| [Sean Goebel](https://youtube.com/@SeanGoebel ) | Photography |
| [Serge Ramelli Photography](https://youtube.com/@SergeRamelliPhotography ) | Photography |
| [Shutter Muse](https://youtube.com/@ShutterMuse ) | Photography |
| [SilverFast – Scan & Archiving Software](https://youtube.com/@LSI-SilverFast ) | Photography |
| [Slanted Lens, The](https://youtube.com/@TheSlantedLens ) | Photography |
| [Slow Mo Guys, The](https://youtube.com/@theslowmoguys ) | Photography |
| [SLR Lounge / Photography Tutorials](https://youtube.com/@slrlounge ) | Photography |
| [SmugMug](https://youtube.com/@SmugMugFilms ) | Photography |
| [Sorelle Amore](https://youtube.com/@SorelleAmore ) | Photography |
| [Steve O'Nions](https://youtube.com/@SteveONions ) | Photography |
| [Steve Perry](https://youtube.com/@backcountrygallery ) | Photography |
| [TheCameraStoreTV](https://youtube.com/@TheCameraStoreTV ) | Photography |
| [Thomas Heaton](https://youtube.com/@ThomasHeatonPhoto ) | Photography |
| [Tony & Chelsea Northrup](https://youtube.com/@TonyAndChelsea ) | Photography |
| [Westcott Lighting](https://youtube.com/@WestcottLighting ) | Photography |
| [Jonathan Notley](https://youtube.com/@JonathanNotley ) | Photography/Film |
| [Zeke Kamm](https://youtube.com/@NiceIndustries ) | Photography/Video |
| [Lincoln Project, The](https://youtube.com/@TheLincolnProject ) | Politics |
| [BPS.space](https://youtube.com/@BPSspace ) | Rocketry |
| [SmarterEveryDay](https://youtube.com/@smartereveryday? ) | Science |
| [Battlestar Galactica](https://youtube.com/@BattlestarGalactica?si=OQjwyxmunuJTvuJA ) | Science Fiction |
| [Doctor Who](https://youtube.com/@DoctorWho ) | Science Fiction |
| [SciTrek](https://youtube.com/@scitrek? ) | Science Fiction News |
| [Albert Bellamy](https://youtube.com/@AlbertBellamy_Major_Data ) | Self Improvement |
| [Visual Education](https://youtube.com/@VisualEducationStudio ) | Software Development |
| [Visual Studio Code](https://youtube.com/@code ) | Software Development |
| [AmericasSpaceShuttle](https://youtube.com/@AmericasSpaceShuttle ) | Space Exploration |
| [European Space Agency, ESA](https://youtube.com/@EuropeanSpaceAgency ) | Space Exploration |
| [Kennedy Space Center Visitor Complex](https://youtube.com/@ExploreSpaceKSC ) | Space Exploration |
| [NASA](https://youtube.com/@NASA ) | Space Exploration |
| [NASA EDGE](https://youtube.com/@NASAedge ) | Space Exploration |
| [NASA Goddard](https://youtube.com/@NASAGoddard? ) | Space Exploration |
| [NASA Kennedy Space Center](https://youtube.com/@NASAKennedy? ) | Space Exploration |
| [NASA Jet Propulsion Laboratory](https://youtube.com/@NASAJPL? ) | Space Exploration |
| [NASA Johnson](https://youtube.com/@ReelNASA? ) | Space Exploration |
| [SpaceX](https://youtube.com/@SpaceX ) | Space Exploration |
| [Connections Museum](https://youtube.com/@ConnectionsMuseum ) | Telephony |
| [Antenna Man](https://youtube.com/@AntennaMan ) | Television Antenna Reviews |
| [DEWALT TV](https://youtube.com/@dewalttv ) | Tools |
| [Kobalt Tools](https://youtube.com/@KobaltTools ) | Tools |
| [GasBuddy](https://youtube.com/@gasbuddy ) | Transportation |
