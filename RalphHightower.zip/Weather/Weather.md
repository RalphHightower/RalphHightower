---
layout: page
title: Weather/Weather
#permalink: /Weather/
---

## Hurricanes[^11]

### Forecasting

| Forecasting | Date |
|---|---|
| [AI Forecasting Case Study: Predicting the 2022 Global Storm Season](https://windbornesystems.com/blog/ai-forecasting-case-study-predicting-the-2022-global-storm-season) | 2024-05-24 |

[^11]: Hurricanes may become a separate page 🌀. — @Ralph Hightower
