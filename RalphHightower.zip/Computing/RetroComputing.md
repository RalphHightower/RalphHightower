---
layout: page
title: Computing/Retro Computing 
#permalink: /Computing/
---

## CPU

| CPU | Date |
|---|---|
| [Retired engineer discovers 55-year-old bug in Lunar Lander computer game code / Ars Technica](https://arstechnica.com/gaming/2024/06/retired-engineer-discovers-55-year-old-bug-in-lunar-lander-computer-game-code/) | 6/14/2024, 2:04 PM |
| [Bringing APL To The Masses: The History Of The IBM 5100 / Hackaday](https://hackaday.com/2023/12/19/bringing-apl-to-the-masses-the-history-of-the-ibm-5100/ ) | December 19, 2023 |
| [Remembering Ed Roberts, The Home Computer Pioneer You Should Have Heard Of But Probably Haven’t / Hackaday](https://hackaday.com/2023/12/17/remembering-ed-roberts-the-home-computer-pioneer-you-should-have-heard-of-but-probably-havent/ ) | December 17, 2023 |
| [Swiss Physicist’s “Big Hack” for Intel 4004’s 52nd Anniversary](https://4004.com/hackaday23/ ) | 2023-Nov-19 |
| [Long gone, DEC is still powering the world of computing / Ars Technica](https://arstechnica.com/gadgets/2023/10/long-gone-dec-is-still-powering-the-world-of-computing/) | 10/6/2023, 7:30 AM |
| [The Rise and Decline of Silicon Art - News](https://www.allaboutcircuits.com/news/the-rise-and-decline-of-silicon-art/ ) | July 11, 2022 |

## Commodore 64

| Commodore 64 | Date |
|---|---|
| [Commodore Floppy Drive Fixing Chaos / Hackaday](https://hackaday.com/2023/06/23/commodore-floppy-drive-fixing-chaos/ ) | June 23, 2023 |
| [1541 Diagnostic Cartridge - World of Jani](https://blog.worldofjani.com/?p=2180 ) | 2015-07-XX |

## YouTube

| YouTube Videos | Date |
|---|---|
| [Is this the FASTEST and CHEAPEST 8-Bit Computer Ever?](https://youtube.com/watch?v=CQ_C_RvJJ9A&si=-Jk-kO-ROlR977ti ) | Oct 3, 023 |
